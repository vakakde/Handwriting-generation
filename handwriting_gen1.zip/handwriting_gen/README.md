# Handwriting generation: LSTM-RNN vs GAN vs Transformer

Reference implementation of *"Comparative Analysis of Handwriting Generation using Deep Learning Architectures"*:
three generators trained and evaluated under **one** protocol (same split, text, style reference, rendering, metrics).

## Quick start
```bash
pip install -r requirements.txt
python run_all.py --smoke --ablation                          # ~1-2 min on CPU, synthetic data: pipeline test only
python run_all.py --data_root /data/IAM-OnDB --ablation --n_eval 200 --device cuda   # real run (manuscript settings)
python run_all.py --data_root ... --human_ratings ratings.csv --human_prefs preferences.csv   # with real rater data
```
Outputs (`runs/<name>/`): `metrics.csv` (one row per model x seed), `ckpt/`, `samples/`, `human/…`, and
`analysis/` with `SUMMARY.md`, `table3_*`, `table5_analogue_scores.*`, `table_seed_significance.*`,
`table_agreement_with_manuscript.*` (csv/md/tex) and figures `fig_quantitative, fig_computational, fig_tradeoff, fig_radar,
fig_training_curves, fig_samples, fig_ablation, fig_human_eval`.

## Files
| file | what it does | manuscript |
|---|---|---|
| `config.py` | all hyper-parameters (+ `Config.smoke()`) | Sec. 4.2-4.3 |
| `data.py` | IAM-OnDB loader, synthetic fallback, **writer-level 70/15/15 split**, train-only standardisation, k=1 style reference | Sec. 4.1, 4.4 (i)(ii) |
| `render.py` | strokes -> anti-aliased image (3 px pen, 4x SSAA) -> **canonicalisation** (ink-box crop, 512x512, 24 px margin) | Sec. 4.4 (iv) |
| `models/lstm.py` | 3x256 LSTM, Gaussian attention window, 20-comp. MDN + pen state, dropout 0.2, priming | Sec. 3.2, Eq. I-X |
| `models/gan.py` | conditional progressive GAN 64->512, spectral norm, self-attention in D, R1 penalty, text + style encoders | Sec. 3.3, Eq. XI-XII |
| `models/transformer.py` | 6 layers / 8 heads / d=512 / ff=2048, text + style encoders, cross-attention, 2-D stroke positional encoding, MDN head; `no-self-attention` ablation | Sec. 3.4, Eq. XIII-XIV |
| `train.py` | Adam, lr 1e-3, cosine annealing, wd 1e-4, 100 epochs, best-validation checkpoint | Sec. 4.3 |
| `metrics.py`, `evaluate.py` | FID (Inception-v3 pool3), SSIM (11x11 Gaussian, sigma 1.5), OCR 1-CER, timing; paired test samples | Sec. 4.5 |
| `human_eval.py` | counterbalanced allocation, simulator, Friedman/Kendall W/Wilcoxon+Holm/rank-biserial/Cronbach/Kruskal/chi-square | Sec. 5.1 |
| `analysis.py` | comparison tables, seed significance tests, Table-5 analogue, all figures | Tables 3-5, Figs 4-5 |

## Design decisions you should know about (the manuscript leaves these open)
1. **LSTM style conditioning** (marked `[verify]` in the manuscript): implemented as Graves *priming* with the reference strokes + text.
2. **Sampling**: LSTM and Transformer share the *same* MDN head and `sample_bias` (0.5) so the "same stochastic-sampling settings" claim holds.
3. **Output length**: `round(median steps-per-char of the training set x len(text))` for both sequence models (no EOS head).
4. **GAN**: number of conv blocks follows from the resolution (4 -> 512 needs 7 doublings, not "5 layers"); "gradient penalty" = R1 on real data;
   `L_rec` = L1 to the real target image; writer labels only train the style encoder. lr 1e-3 / beta1 0.9 as in the manuscript is aggressive for GANs
   - set `gan_lr`, `betas` if training is unstable.
5. **Transformer**: linear warm-up (200 steps) before cosine annealing; generation recomputes the prefix every step (no KV-cache), so inference
   time will not match the 0.031 s in the manuscript until a cache is added.
6. **FID with small N**: with N = 5 the covariance is rank <= 4; the code uses an exact nuclear-norm identity (verified against `sqrtm`), but
   the estimate is still extremely noisy. Use `--n_eval` in the hundreds for conclusions.
7. **Table-5 analogue** is computed from measured quantities (see `analysis.table5_analogue`), not the subjective scores in the manuscript.
8. **OCR**: `auto` = TrOCR (`microsoft/trocr-base-handwritten`) if `transformers` is installed, else Tesseract. State the engine/version in the paper.

## Limitations of this delivery
* The IAM-OnDB parser follows the public XML layout but could **not** be tested against the real data here - check the first few samples.
* With no IAM-OnDB, `data.py` falls back to synthetic pseudo-handwriting; with no internet, FID falls back to a random extractor
  ("pseudo-FID"). Both are announced in the logs and in `SUMMARY.md`. Numbers from such runs are *not* results.
* Human-study numbers produced by `human_eval.py simulate` are simulated (files prefixed `SIMULATED_`).
* Full-resolution (512 px) GAN training and 100-epoch LSTM/Transformer training need a GPU; the Graves attention layer is a Python time-loop.

## Supplementary-materials tables
`python scripts/make_supplement_tables.py --ratings data/human_eval/ratings.csv --prefs data/human_eval/prefs.csv --allocation data/human_eval/allocation.csv --run_dir runs/main --out_dir supplement_tables`
builds Tables S3-1 (verified counts), S3-2 (Friedman / Kendall W / Wilcoxon+Holm / rank-biserial / Cronbach alpha), S3-3 (category x preference counts),
S4-1 (parameters, filled from `runs/<run>/eval_params.json`), S5-1 and `configs/eval.yaml`. With `--simulate` it fabricates TEST ratings (files prefixed `SIMULATED_`).
Rating/preference file formats follow Supplement S3-1 (`ratings.csv`: participant_id, category, trial, model, item, score; `prefs.csv`: participant_id, question, chosen_model).
