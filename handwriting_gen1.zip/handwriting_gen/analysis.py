"""
Comparison analysis of LSTM-RNN vs GAN vs Transformer: tables (CSV / Markdown / LaTeX), significance tests over seeds,
a data-driven analogue of manuscript Table 5, and all figures.

    python analysis.py --run_dir runs/main [--human_dir runs/human]
"""
from __future__ import annotations
import argparse, glob, itertools, json, os
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from paper_reference import PAPER_T3, PAPER_T3_SD, PAPER_T4, PAPER_T5, PAPER_ABLATION

MODELS = ["lstm", "gan", "transformer"]
LABEL = {"lstm": "LSTM-RNN", "gan": "GAN", "transformer": "Transformer", "transformer_noattn": "Transformer\n(no self-attn)"}
COLOR = {"lstm": "#4C72B0", "gan": "#DD8452", "transformer": "#55A868", "transformer_noattn": "#8C8C8C"}
plt.rcParams.update({"figure.dpi": 130, "axes.spines.top": False, "axes.spines.right": False, "font.size": 9})


# ---------------------------------------------------------------------------- helpers
def to_md(df: pd.DataFrame, floatfmt="{:.3f}") -> str:
    d = df.copy()
    cols = [str(c) for c in d.columns]
    rows = [[floatfmt.format(v) if isinstance(v, (float, np.floating)) else str(v) for v in r] for r in d.values]
    w = [max(len(c), *(len(r[i]) for r in rows)) for i, c in enumerate(cols)]
    line = lambda r: "| " + " | ".join(x.ljust(w[i]) for i, x in enumerate(r)) + " |"
    return "\n".join([line(cols), "|" + "|".join("-" * (x + 2) for x in w) + "|"] + [line(r) for r in rows])


def save_table(df, path_noext, index=False, floatfmt="{:.3f}"):
    df.to_csv(path_noext + ".csv", index=index)
    open(path_noext + ".md", "w").write(to_md(df.reset_index() if index else df, floatfmt))
    try:
        open(path_noext + ".tex", "w").write(df.to_latex(index=index, float_format=lambda x: f"{x:.3f}", escape=True))
    except Exception:
        pass


def msd(x, f="{:.3f}"):
    x = np.asarray(x, float)
    return (f + " ± " + f).format(np.nanmean(x), np.nanstd(x, ddof=1) if np.sum(~np.isnan(x)) > 1 else 0.0)


def cohen_d(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    sp = np.sqrt(((len(a) - 1) * a.var(ddof=1) + (len(b) - 1) * b.var(ddof=1)) / max(len(a) + len(b) - 2, 1))
    return float((a.mean() - b.mean()) / sp) if sp > 0 else float("nan")


# ----------------------------------------------------------------------------- tables
def table3(df):
    rows = []
    for m in MODELS:
        d = df[df.model == m]
        if d.empty:
            continue
        rows.append({"Model": LABEL[m], "FID ↓": msd(d.fid, "{:.2f}"), "SSIM ↑": msd(d.ssim),
                     "OCR acc ↑ (%)": msd(d.ocr_acc * 100, "{:.1f}"), "Train time ↓ (h)": msd(d.train_time_h, "{:.3f}"),
                     "Inference ↓ (s/sample)": msd(d.inference_time_s, "{:.4f}"), "Params (M)": f"{d.n_params.iloc[0] / 1e6:.2f}",
                     "seeds": len(d)})
    return pd.DataFrame(rows)


def seed_tests(df):
    rows = []
    for metric in ["fid", "ssim", "ocr_acc", "inference_time_s", "train_time_h"]:
        for a, b in itertools.combinations(MODELS, 2):
            x, y = df[df.model == a][metric].values, df[df.model == b][metric].values
            if len(x) < 2 or len(y) < 2:
                continue
            t, p = stats.ttest_ind(x, y, equal_var=False)
            rows.append(dict(metric=metric, pair=f"{a} vs {b}", mean_a=x.mean(), mean_b=y.mean(), welch_t=t, p=p, cohen_d=cohen_d(x, y)))
    if not rows:
        return pd.DataFrame()
    t = pd.DataFrame(rows)
    p = t.p.values; order = np.argsort(p); m = len(p); adj = np.empty(m); run = 0
    for rk, i in enumerate(order):                                   # Holm over all comparisons
        run = max(run, (m - rk) * p[i]); adj[i] = min(1, run)
    t["p_holm"] = adj
    return t


def table5_analogue(df):
    """Data-driven analogue of manuscript Table 5 (0-10 scales, 10 = best of the three models).
    Visual quality    : mean of FID, SSIM, OCR ratios-to-best
    Temporal consist. : stroke continuity (connected-component fragmentation vs real) ratio-to-best
    Style control     : Inception-space cosine similarity gen-vs-style-reference, ratio-to-best
    Training stability: 1/(val-loss volatility + CV of FID across seeds), ratio-to-best
    Comput. efficiency: geometric mean of train-time and inference-time ratios-to-best"""
    g = df[df.model.isin(MODELS)].groupby("model")
    mean = g.mean(numeric_only=True)
    cv_fid = g.fid.std(ddof=1) / g.fid.mean()
    cv_fid = cv_fid.fillna(0)
    best_hi = lambda s: s / s.max()
    best_lo = lambda s: s.min() / s
    vq_parts = [best_lo(mean.fid), best_hi(mean.ssim)]
    if mean.ocr_acc.notna().all() and mean.ocr_acc.max() > 0:
        vq_parts.append(best_hi(mean.ocr_acc))
    vq = sum(vq_parts) / len(vq_parts)
    unstable = mean.val_volatility + cv_fid
    ts = best_lo(unstable.clip(lower=1e-6))
    eff = np.sqrt(best_lo(mean.train_time_h) * best_lo(mean.inference_time_s))
    t5 = pd.DataFrame({"Visual Quality": 10 * vq, "Temporal Consistency": 10 * best_hi(mean.stroke_continuity),
                       "Style Control": 10 * best_hi(mean.style_sim), "Training Stability": 10 * ts,
                       "Computational Efficiency": 10 * eff}).reindex([m for m in MODELS if m in mean.index])
    t5["Overall Score"] = t5.mean(axis=1)
    return t5


def tradeoff_table(t5):
    return t5.round(2)


# ---------------------------------------------------------------------------- figures
def _bars(ax, df, metric, title, scale=1.0, fmt="{:.2f}", paper_key=None, ylabel=None):
    xs = np.arange(len(MODELS))
    mu = [df[df.model == m][metric].mean() * scale for m in MODELS]
    sd = [df[df.model == m][metric].std(ddof=1) * scale if (df.model == m).sum() > 1 else 0 for m in MODELS]
    ax.bar(xs, mu, yerr=sd, color=[COLOR[m] for m in MODELS], capsize=4, alpha=.9)
    for x, v in zip(xs, mu):
        ax.text(x, v, fmt.format(v), ha="center", va="bottom", fontsize=8)
    if paper_key:
        pv = [PAPER_T3[m][paper_key] * (100 if paper_key == "ocr_acc" and scale == 100 else 1) for m in MODELS]
        ax.scatter(xs, pv, marker="D", color="k", zorder=5, label="manuscript")
        ax.legend(frameon=False, fontsize=7)
    ax.set_xticks(xs); ax.set_xticklabels([LABEL[m] for m in MODELS]); ax.set_title(title)
    if ylabel:
        ax.set_ylabel(ylabel)


def fig_quant(df, out):
    fig, ax = plt.subplots(1, 3, figsize=(11, 3.4))
    _bars(ax[0], df, "fid", "FID ↓", paper_key="fid")
    _bars(ax[1], df, "ssim", "SSIM ↑", paper_key="ssim")
    _bars(ax[2], df, "ocr_acc", "OCR accuracy (1−CER) ↑ [%]", scale=100, fmt="{:.1f}", paper_key="ocr_acc")
    fig.suptitle("Quantitative quality (mean ± SD over seeds; ◆ = value reported in the manuscript)", y=1.03)
    fig.tight_layout(); fig.savefig(out, bbox_inches="tight"); plt.close(fig)


def fig_comp(df, out):
    fig, ax = plt.subplots(1, 3, figsize=(11, 3.2))
    _bars(ax[0], df, "train_time_h", "Training time [h]", fmt="{:.3f}", paper_key="train_time_h")
    _bars(ax[1], df, "inference_time_s", "Inference time [s / sample]", fmt="{:.4f}", paper_key="inference_time_s")
    xs = np.arange(len(MODELS)); pm = [df[df.model == m].n_params.iloc[0] / 1e6 for m in MODELS]
    ax[2].bar(xs, pm, color=[COLOR[m] for m in MODELS]); ax[2].set_title("Trainable parameters [M]")
    for x, v in zip(xs, pm):
        ax[2].text(x, v, f"{v:.2f}", ha="center", va="bottom", fontsize=8)
    ax[2].set_xticks(xs); ax[2].set_xticklabels([LABEL[m] for m in MODELS])
    fig.tight_layout(); fig.savefig(out, bbox_inches="tight"); plt.close(fig)


def fig_tradeoff(df, out):
    fig, ax = plt.subplots(figsize=(4.8, 3.8))
    for m in MODELS:
        d = df[df.model == m]
        ax.scatter(d.inference_time_s, d.fid, s=60 + 4000 * d.train_time_h / max(df.train_time_h.max(), 1e-9) * .1,
                   color=COLOR[m], alpha=.55, label=LABEL[m], edgecolor="k", linewidth=.4)
        ax.scatter(d.inference_time_s.mean(), d.fid.mean(), marker="X", s=90, color=COLOR[m], edgecolor="k")
    ax.set_xlabel("Inference time [s / sample]"); ax.set_ylabel("FID ↓")
    ax.set_title("Quality–speed trade-off (bubble ∝ training time)"); ax.legend(frameon=False, fontsize=8)
    fig.tight_layout(); fig.savefig(out); plt.close(fig)


def fig_radar(t5, out, paper=False):
    cats = list(t5.columns[:-1]); ang = np.linspace(0, 2 * np.pi, len(cats), endpoint=False).tolist(); ang += ang[:1]
    fig, axs = plt.subplots(1, 2 if paper else 1, subplot_kw=dict(polar=True), figsize=(9.5 if paper else 5, 4.4))
    axs = np.atleast_1d(axs)
    for m in t5.index:
        v = t5.loc[m, cats].tolist(); v += v[:1]
        axs[0].plot(ang, v, color=COLOR[m], label=LABEL[m]); axs[0].fill(ang, v, color=COLOR[m], alpha=.12)
    axs[0].set_xticks(ang[:-1]); axs[0].set_xticklabels([c.replace(" ", "\n") for c in cats], fontsize=7); axs[0].set_ylim(0, 10)
    axs[0].set_title("This run (data-driven)", fontsize=9); axs[0].legend(loc="lower right", bbox_to_anchor=(1.25, -.1), frameon=False, fontsize=7)
    if paper:
        for m in MODELS:
            v = list(PAPER_T5[m][:5]); v += v[:1]
            axs[1].plot(ang, v, color=COLOR[m]); axs[1].fill(ang, v, color=COLOR[m], alpha=.12)
        axs[1].set_xticks(ang[:-1]); axs[1].set_xticklabels([c.replace(" ", "\n") for c in cats], fontsize=7); axs[1].set_ylim(0, 10)
        axs[1].set_title("Manuscript Table 5 (as reported)", fontsize=9)
    fig.tight_layout(); fig.savefig(out, bbox_inches="tight"); plt.close(fig)


def fig_curves(run_dir, out):
    fig, ax = plt.subplots(1, 2, figsize=(10, 3.4))
    for m in MODELS + ["transformer_noattn"]:
        for i, p in enumerate(sorted(glob.glob(os.path.join(run_dir, "ckpt", f"{m}_seed*_history.json")))):
            h = json.load(open(p)); a = ax[1] if m == "gan" else ax[0]
            a.plot(range(1, len(h["val_loss"]) + 1), h["val_loss"], color=COLOR[m], alpha=.75, ls="-" if m != "transformer_noattn" else "--",
                   label=LABEL[m].replace("\n", " ") if i == 0 else None)
    ax[0].set_title("Validation NLL (LSTM / Transformer)"); ax[0].set_xlabel("epoch"); ax[0].legend(frameon=False, fontsize=7)
    ax[1].set_title("GAN validation L1 reconstruction"); ax[1].set_xlabel("epoch")
    fig.tight_layout(); fig.savefig(out); plt.close(fig)


def fig_samples(run_dir, out, seed=0, n=4):
    sd = os.path.join(run_dir, "samples")
    if not os.path.exists(os.path.join(sd, "real.npz")):
        return
    real = np.load(os.path.join(sd, "real.npz"))
    rows = [("Ground truth", real["gen"])]
    for m in MODELS:
        p = os.path.join(sd, f"{m}_seed{seed}.npz")
        if os.path.exists(p):
            rows.append((LABEL[m].replace("\n", " "), np.load(p)["gen"]))
    n = min(n, len(real["gen"]))
    fig, ax = plt.subplots(len(rows), n, figsize=(2.6 * n, 2.6 * len(rows)))
    ax = np.atleast_2d(ax)
    for r, (name, imgs) in enumerate(rows):
        for c in range(n):
            ax[r, c].imshow(imgs[c], cmap="gray", vmin=0, vmax=255); ax[r, c].set_xticks([]); ax[r, c].set_yticks([])
            if c == 0:
                ax[r, c].set_ylabel(name, fontsize=9)
            if r == 0:
                ax[r, c].set_title(f"“{real['texts'][c]}”", fontsize=8)
    fig.suptitle(f"Paired outputs (same text + same writer reference), seed {seed}", y=1.0)
    fig.tight_layout(); fig.savefig(out, bbox_inches="tight"); plt.close(fig)


def fig_ablation(df, out):
    if "transformer_noattn" not in df.model.values:
        return None
    fig, ax = plt.subplots(1, 3, figsize=(9, 3))
    for a, (metric, title, sc) in zip(ax, [("fid", "FID ↓", 1), ("ssim", "SSIM ↑", 1), ("ocr_acc", "OCR acc [%] ↑", 100)]):
        names = ["transformer", "transformer_noattn"]
        mu = [df[df.model == n][metric].mean() * sc for n in names]
        sd = [df[df.model == n][metric].std(ddof=1) * sc if (df.model == n).sum() > 1 else 0 for n in names]
        a.bar(range(2), mu, yerr=sd, color=[COLOR[n] for n in names], capsize=4)
        pa = PAPER_ABLATION; key = {"fid": "fid", "ssim": "ssim", "ocr_acc": "ocr_acc"}[metric]
        a.scatter([0, 1], [pa["with_attention"][key] * (100 if sc == 100 else 1), pa["without_attention"][key] * (100 if sc == 100 else 1)],
                  marker="D", color="k", zorder=5, label="manuscript")
        a.set_xticks(range(2)); a.set_xticklabels(["with\nself-attn", "without\nself-attn"]); a.set_title(title)
    ax[0].legend(frameon=False, fontsize=7); fig.suptitle("Attention ablation (decoder self-attention removed)", y=1.03)
    fig.tight_layout(); fig.savefig(out, bbox_inches="tight"); plt.close(fig)


def fig_human(human_dir, out):
    f = os.path.join(human_dir, "human_table4_numeric.csv")
    if not os.path.exists(f):
        return
    t = pd.read_csv(f); crits = ["legibility", "naturalness", "style_consistency", "overall_quality"]
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.4), gridspec_kw=dict(width_ratios=[2, 1]))
    w = 0.26
    for i, m in enumerate(MODELS):
        d = t[t.model == m].set_index("criterion").reindex(crits)
        ax[0].bar(np.arange(4) + (i - 1) * w, d["mean"], w, yerr=d["std"], color=COLOR[m], label=LABEL[m], capsize=3)
    ax[0].set_xticks(range(4)); ax[0].set_xticklabels([c.replace("_", "\n") for c in crits]); ax[0].set_ylim(1, 10)
    ax[0].set_ylabel("rating (1–10)"); ax[0].legend(frameon=False, fontsize=7, ncol=3); ax[0].set_title("Human evaluation (mean ± SD over participants)")
    pf = os.path.join(human_dir, "human_preferences.csv")
    if os.path.exists(pf):
        p = pd.read_csv(pf).set_index("question")[MODELS]
        bottom = np.zeros(len(p))
        for m in MODELS:
            ax[1].barh(range(len(p)), p[m], left=bottom, color=COLOR[m], label=LABEL[m]); bottom += p[m].values
        ax[1].set_yticks(range(len(p))); ax[1].set_yticklabels(p.index); ax[1].set_title("Preferred sample (count)")
    fig.tight_layout(); fig.savefig(out, bbox_inches="tight"); plt.close(fig)


# ------------------------------------------------------------------------------- main
def run_analysis(run_dir, human_dir=None):
    out = os.path.join(run_dir, "analysis"); os.makedirs(out, exist_ok=True)
    df = pd.read_csv(os.path.join(run_dir, "metrics.csv"))
    synthetic = bool(df.synthetic_data.iloc[0]) if "synthetic_data" in df else False
    pre = bool(df.fid_pretrained_extractor.iloc[0]) if "fid_pretrained_extractor" in df else True
    notes = []
    if synthetic:
        notes.append("DATA: synthetic fallback (IAM-OnDB not found). Numbers validate the pipeline only.")
    if not pre:
        notes.append("FID: random (non-pretrained) Inception features -> pseudo-FID, not comparable to published FID.")
    if int(df.n_eval.iloc[0]) < 50:
        notes.append(f"FID/SSIM/OCR estimated from N={int(df.n_eval.iloc[0])} test samples per model: very high variance.")

    t3 = table3(df); save_table(t3, os.path.join(out, "table3_quantitative"))
    st = seed_tests(df)
    if len(st):
        save_table(st, os.path.join(out, "table_seed_significance"), floatfmt="{:.4g}")
    t5 = table5_analogue(df); save_table(t5.round(2), os.path.join(out, "table5_analogue_scores"), index=True, floatfmt="{:.2f}")
    paper5 = pd.DataFrame(PAPER_T5, index=list(t5.columns)).T.loc[MODELS]; paper5.to_csv(os.path.join(out, "table5_manuscript_reference.csv"))
    # rank agreement between this run and the manuscript claims
    rank = {}
    for metric, better in [("fid", "min"), ("ssim", "max"), ("ocr_acc", "max"), ("train_time_h", "min"), ("inference_time_s", "min")]:
        mu = df[df.model.isin(MODELS)].groupby("model")[metric].mean()
        mine = mu.idxmin() if better == "min" else mu.idxmax()
        pp = pd.Series({m: PAPER_T3[m][metric] for m in MODELS}); paper = pp.idxmin() if better == "min" else pp.idxmax()
        rank[metric] = dict(best_in_this_run=mine, best_in_manuscript=paper, agrees=mine == paper)
    save_table(pd.DataFrame(rank).T.reset_index().rename(columns={"index": "metric"}), os.path.join(out, "table_agreement_with_manuscript"))

    fig_quant(df, os.path.join(out, "fig_quantitative.png")); fig_comp(df, os.path.join(out, "fig_computational.png"))
    fig_tradeoff(df, os.path.join(out, "fig_tradeoff.png")); fig_radar(t5, os.path.join(out, "fig_radar.png"), paper=True)
    fig_curves(run_dir, os.path.join(out, "fig_training_curves.png")); fig_samples(run_dir, os.path.join(out, "fig_samples.png"))
    fig_ablation(df, os.path.join(out, "fig_ablation.png"))
    if human_dir:
        fig_human(human_dir, os.path.join(out, "fig_human_eval.png"))

    with open(os.path.join(out, "SUMMARY.md"), "w") as f:
        f.write("# Comparison analysis: LSTM-RNN vs GAN vs Transformer\n\n")
        for n in notes:
            f.write(f"> **{n}**\n\n")
        f.write("## Quantitative results (mean ± SD over seeds)\n\n" + to_md(t3) + "\n\n")
        f.write("## Data-driven analogue of Table 5 (0–10, 10 = best of the three)\n\n" + to_md(t5.round(2).reset_index(), "{:.2f}") + "\n\n")
        if len(st):
            f.write("## Pairwise tests over seeds (Welch t, Holm-adjusted)\n\n" + to_md(st, "{:.4g}") + "\n\n")
        f.write("## Agreement of metric winners with the manuscript\n\n" + to_md(pd.DataFrame(rank).T.reset_index().rename(columns={"index": "metric"})) + "\n")
    print(open(os.path.join(out, "SUMMARY.md")).read())
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--run_dir", required=True); ap.add_argument("--human_dir", default=None)
    a = ap.parse_args()
    run_analysis(a.run_dir, a.human_dir)
