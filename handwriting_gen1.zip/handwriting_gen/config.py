"""
Central configuration.  Every default below is taken from the manuscript
("Comparative Analysis of Handwriting Generation using Deep Learning
Architectures") unless a comment says otherwise.  `Config.smoke()` returns a
tiny configuration that runs end-to-end on a CPU in a few minutes; it exists
to validate the pipeline, NOT to reproduce the paper's numbers.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, field, asdict
from typing import List, Tuple

# One shared character set + text normalisation for all models (paper, Sec. 4.4 (i)).
# index 0 is reserved for padding.
CHARSET = " abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,'-!?:;\"()"


@dataclass
class Config:
    # ------------------------------------------------------------------ paths
    data_root: str = "data/IAM-OnDB"      # contains lineStrokes/, ascii/, original-xml-part/
    out_dir: str = "runs/main"
    device: str = "auto"                  # auto | cpu | cuda

    # ------------------------------------------------------------------- data
    use_synthetic: str = "auto"           # auto: synthetic only if IAM-OnDB is not found | yes | no
    n_synth_writers: int = 60
    synth_samples_per_writer: int = 20
    synth_words_per_line: Tuple[int, int] = (2, 4)
    max_seq_len: int = 700                # lines with more pen points are dropped
    max_text_len: int = 64
    split: Tuple[float, float, float] = (0.70, 0.15, 0.15)   # writer-level split
    split_seed: int = 2026
    iam_target_line_width_px: float = 900.0   # IAM-OnDB units are rescaled so the median line is this wide

    # ------------------------------------------------ rendering / canonicalisation
    pen_width: int = 3
    ssaa: int = 4                         # anti-aliasing factor (render at 4x, area-downsample)
    canvas: int = 512
    margin: int = 24
    ink_threshold: float = 0.5

    # ---------------------------------------------------------------- training
    seeds: List[int] = field(default_factory=lambda: [0, 1, 2, 3, 4])
    epochs: int = 100
    lr: float = 1e-3
    weight_decay: float = 1e-4
    betas: Tuple[float, float] = (0.9, 0.999)
    batch_size: int = 64                  # LSTM + Transformer
    gan_batch_size: int = 32
    warmup_steps: int = 200               # linear warm-up before cosine annealing (added for Transformer stability)
    grad_clip_lstm: float = 10.0
    grad_clip_transformer: float = 1.0
    num_workers: int = 0

    # -------------------------------------------------------------------- LSTM
    lstm_layers: int = 3
    lstm_hidden: int = 256
    lstm_dropout: float = 0.2
    n_mix: int = 20                       # Gaussian components (shared by LSTM and Transformer heads)
    window_K: int = 10                    # Gaussians of the Graves attention window
    char_emb: int = 64

    # --------------------------------------------------------------------- GAN
    gan_z_dim: int = 100
    gan_res_schedule: List[int] = field(default_factory=lambda: [64, 128, 256, 512])
    gan_base_ch: int = 256
    gan_text_dim: int = 128
    gan_style_dim: int = 128
    gan_lambda_rec: float = 10.0          # lambda of L_G = -E[log D(G(z,c))] + lambda * L_rec
    gan_r1_gamma: float = 10.0            # gradient-penalty (R1) weight
    gan_r1_interval: int = 4              # lazy regularisation
    gan_style_ce_weight: float = 0.1      # writer-ID loss for the style encoder (labels used for training only)
    gan_lr: float = -1.0                  # <0 => use `lr`.  (2e-4 with betas (0,0.99) is the usual GAN choice)

    # ------------------------------------------------------------- Transformer
    tf_d_model: int = 512
    tf_heads: int = 8
    tf_layers: int = 6
    tf_ff: int = 2048
    tf_dropout: float = 0.1
    tf_style_layers: int = 2
    tf_style_ce_weight: float = 0.1
    tf_pos_scale: float = 1.0 / 100.0     # scale of absolute (x, y) before the 2-D stroke positional encoding

    # ---------------------------------------------------------------- sampling
    sample_bias: float = 0.5              # Graves bias, SAME value for LSTM and Transformer (paper placeholder [bias/temperature])
    length_mode: str = "rate"             # output length = round(steps_per_char * len(text)), same rule for LSTM and Transformer

    # -------------------------------------------------------------- evaluation
    n_eval: int = 5                       # N test samples of the manuscript.  FID with N=5 is statistically very weak -> raise it.
    eval_seed: int = 2026
    ocr_backend: str = "auto"             # auto | trocr | tesseract | none
    fid_backend: str = "auto"             # auto | inception | random (random = pipeline test only!)

    # ------------------------------------------------------------- human study
    n_participants: int = 53
    n_trials: int = 6
    human_seed: int = 2026
    category_counts: Tuple[int, int, int] = (8, 10, 35)   # faculty, PhD scholars, PG students (Supplement S3-1)

    # ------------------------------------------------------------------ helpers
    def save(self, path: str):
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2)

    @classmethod
    def smoke(cls, **kw) -> "Config":
        """Tiny configuration: validates the whole pipeline on CPU in minutes."""
        c = cls(
            out_dir="runs/smoke", n_synth_writers=14, synth_samples_per_writer=8,
            synth_words_per_line=(1, 2), max_seq_len=220, max_text_len=12,
            seeds=[0, 1], epochs=4, batch_size=16, gan_batch_size=16, warmup_steps=10,
            lstm_hidden=64, n_mix=5, window_K=4, char_emb=24,
            gan_res_schedule=[16, 32], gan_base_ch=32, gan_text_dim=32, gan_style_dim=32, gan_z_dim=32,
            tf_d_model=64, tf_heads=4, tf_layers=2, tf_ff=128, tf_style_layers=1,
            n_eval=6, n_participants=53,
        )
        for k, v in kw.items():
            setattr(c, k, v)
        return c
