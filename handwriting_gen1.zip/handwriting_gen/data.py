"""
Data handling: IAM-OnDB loader, synthetic fallback, writer-level split, datasets.

IAM-OnDB (online strokes) must be obtained from the providers (licence):
https://fki.tic.heia-fr.ch/databases/iam-on-line-handwriting-database
Expected layout under cfg.data_root:
    lineStrokes/a01/a01-000/a01-000u-01.xml
    ascii/a01/a01-000/a01-000u.txt
    original-xml-part/original/a01/a01-000/original-a01-000u.xml   (writer id)
The loader below follows the public format description; verify it on your copy.

If IAM-OnDB is not present, a deterministic SYNTHETIC writer-style generator is used so that the
entire pipeline can be executed and tested.  Synthetic numbers are NOT comparable to the paper.
"""
from __future__ import annotations
import glob, os, re, math, json
import xml.etree.ElementTree as ET
from collections import defaultdict
from dataclasses import dataclass
from typing import List, Dict

import numpy as np
import torch
from torch.utils.data import Dataset

from config import CHARSET, Config


# ----------------------------------------------------------------------------- vocab
class Vocab:
    def __init__(self, charset: str = CHARSET):
        self.chars = charset
        self.c2i = {c: i + 1 for i, c in enumerate(charset)}      # 0 = PAD
        self.size = len(charset) + 1

    def normalise(self, text: str) -> str:
        return "".join(c for c in text if c in self.c2i)

    def encode(self, text: str) -> np.ndarray:
        return np.array([self.c2i[c] for c in self.normalise(text)], dtype=np.int64)


@dataclass
class Sample:
    strokes: np.ndarray     # (T,3) raw offsets (dx, dy, p) in px-like units
    text: str
    writer: str
    sid: str


# --------------------------------------------------------------------------- synthetic
_WORDS = ("the hand write model deep learn stroke pen line text style ink word paper mind clear "
          "draw form data image slow quick brown fox jump over lazy dog river stone cloud light").split()


def _catmull_rom(ctrl: np.ndarray, n: int = 5) -> np.ndarray:
    p = np.vstack([ctrl[0], ctrl, ctrl[-1]])
    out = []
    for i in range(1, len(p) - 2):
        p0, p1, p2, p3 = p[i - 1], p[i], p[i + 1], p[i + 2]
        for t in np.linspace(0, 1, n, endpoint=False):
            out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t ** 2
                              + (-p0 + 3 * p1 - 3 * p2 + p3) * t ** 3))
    out.append(p[-2])
    return np.array(out)


_GLYPHS: Dict[str, list] = {}


def _glyph(ch: str):
    """Deterministic pseudo-glyph per character (1-2 smooth strokes inside a unit box, y down)."""
    if ch not in _GLYPHS:
        rng = np.random.default_rng((ord(ch) * 2654435761) % (2 ** 32))
        strokes = []
        if ch != " ":
            for _ in range(1 + int(rng.random() < 0.35)):
                k = int(rng.integers(4, 7))
                ctrl = np.stack([rng.uniform(0, 0.8, k), rng.uniform(0, 1.0, k)], 1)
                strokes.append(_catmull_rom(ctrl, 4))
        _GLYPHS[ch] = strokes
    return _GLYPHS[ch]


def synth_line(text: str, wp: dict, rng: np.random.Generator) -> np.ndarray:
    cursor, pts, ends = 0.0, [], []
    for ch in text:
        for g in _glyph(ch):
            p = g.copy()
            p[:, 0] *= wp["cw"] * 40
            p[:, 1] *= wp["sc"] * 60
            p[:, 0] += p[:, 1] * wp["slant"]
            p += rng.normal(0, wp["jit"], p.shape)
            p[:, 0] += cursor
            p[:, 1] += wp["wob"] * math.sin(cursor / 60.0 + wp["ph"])
            pts.append(p)
            ends.append(len(p))
        cursor += wp["adv"] * (30 if ch != " " else 26)
    if not pts:
        pts, ends = [np.zeros((2, 2))], [2]
    P = np.vstack(pts)
    off = np.diff(P, axis=0, prepend=P[:1])
    pen = np.zeros(len(P), np.float32)
    pen[np.cumsum(ends) - 1] = 1.0
    return np.concatenate([off, pen[:, None]], 1).astype(np.float32)


def make_synthetic(cfg: Config) -> List[Sample]:
    rng = np.random.default_rng(cfg.split_seed)
    out = []
    for w in range(cfg.n_synth_writers):
        wp = dict(slant=rng.normal(0, 0.35), sc=rng.uniform(0.8, 1.25), cw=rng.uniform(0.7, 1.1),
                  adv=rng.uniform(0.8, 1.2), jit=rng.uniform(0.2, 1.2), wob=rng.uniform(0, 6),
                  ph=rng.uniform(0, 6.28))
        for s in range(cfg.synth_samples_per_writer):
            nw = int(rng.integers(cfg.synth_words_per_line[0], cfg.synth_words_per_line[1] + 1))
            text = " ".join(rng.choice(_WORDS, nw))[: cfg.max_text_len].strip()
            st = synth_line(text, wp, rng)
            if len(st) <= cfg.max_seq_len:
                out.append(Sample(st, text, f"w{w:03d}", f"w{w:03d}-{s:03d}"))
    return out


# -------------------------------------------------------------------------- IAM-OnDB
def load_iam_ondb(cfg: Config) -> List[Sample]:
    root = cfg.data_root
    files = sorted(glob.glob(os.path.join(root, "lineStrokes", "*", "*", "*.xml")))
    if not files:
        raise FileNotFoundError(f"No IAM-OnDB line strokes under {root}/lineStrokes")
    writer_cache: Dict[str, str] = {}
    samples = []
    for f in files:
        base = os.path.basename(f)[:-4]                       # a01-000u-01
        m = re.match(r"(.+?)-(\d+)$", base)
        form, line_no = m.group(1), int(m.group(2))
        d1 = form.split("-")[0]                                  # a01
        d2 = re.match(r"([a-z]\d\d-\d+)", form).group(1)          # a01-000
        # transcription
        tx = glob.glob(os.path.join(root, "ascii", d1, d2, form + ".txt"))
        if not tx:
            continue
        txt = open(tx[0], encoding="latin-1").read().split("CSR:")[-1].strip().splitlines()
        if line_no > len(txt):
            continue
        text = txt[line_no - 1].strip()
        # writer id
        if form not in writer_cache:
            ox = glob.glob(os.path.join(root, "original-xml-part", "original", d1, d2, f"original-{form}.xml"))
            wid = "unknown"
            if ox:
                mm = re.search(r'writerID="(\d+)"', open(ox[0], encoding="latin-1").read())
                wid = mm.group(1) if mm else "unknown"
            writer_cache[form] = wid
        # strokes
        tree = ET.parse(f)
        pts, ends = [], []
        for st in tree.getroot().iter("Stroke"):
            sp = [(float(p.get("x")), float(p.get("y"))) for p in st.iter("Point")]
            if len(sp) >= 1:
                pts.extend(sp)
                ends.append(len(sp))
        if not pts:
            continue
        P = np.array(pts, np.float64)
        pen = np.zeros(len(P), np.float32)
        pen[np.cumsum(ends) - 1] = 1.0
        off = np.diff(P, axis=0, prepend=P[:1])
        samples.append(Sample(np.concatenate([off, pen[:, None]], 1).astype(np.float32), text,
                              writer_cache[form], base))
    if not samples:
        raise RuntimeError("IAM-OnDB parsing produced no samples - check the directory layout.")
    # rescale units so that the median line is cfg.iam_target_line_width_px wide (px-like units)
    widths = [np.ptp(np.cumsum(s.strokes[:, 0])) for s in samples]
    k = cfg.iam_target_line_width_px / max(np.median(widths), 1e-6)
    for s in samples:
        s.strokes[:, :2] *= k
    return samples


def load_samples(cfg: Config) -> (List[Sample], bool):
    has_iam = os.path.isdir(os.path.join(cfg.data_root, "lineStrokes"))
    if cfg.use_synthetic == "yes" or (cfg.use_synthetic == "auto" and not has_iam):
        print("[data] IAM-OnDB not found -> using SYNTHETIC data (pipeline test only; numbers are not comparable to the paper)")
        samples, synthetic = make_synthetic(cfg), True
    else:
        samples, synthetic = load_iam_ondb(cfg), False
    vocab = Vocab()
    kept = []
    for s in samples:
        s.text = vocab.normalise(s.text)[: cfg.max_text_len]
        if 0 < len(s.strokes) <= cfg.max_seq_len and len(s.text) > 0:
            kept.append(s)
    print(f"[data] {len(kept)} samples, {len(set(s.writer for s in kept))} writers")
    return kept, synthetic


# ------------------------------------------------------------------------------ split
def writer_level_split(samples: List[Sample], cfg: Config):
    """70/15/15 split by WRITER (not by sample): test writers are never seen in training/validation."""
    by_w = defaultdict(list)
    for i, s in enumerate(samples):
        by_w[s.writer].append(i)
    writers = sorted(w for w, v in by_w.items() if len(v) >= 2)       # need >=2 samples (target + disjoint style reference)
    rng = np.random.default_rng(cfg.split_seed)
    rng.shuffle(writers)
    n = len(writers)
    n_tr = max(1, int(round(cfg.split[0] * n)))
    n_va = max(1, int(round(cfg.split[1] * n)))
    parts = {"train": writers[:n_tr], "val": writers[n_tr:n_tr + n_va], "test": writers[n_tr + n_va:]}
    if not parts["test"]:                       # tiny datasets
        parts["test"] = [parts["val"].pop()] if len(parts["val"]) > 1 else [parts["train"].pop()]
    idx = {k: [i for w in ws for i in by_w[w]] for k, ws in parts.items()}
    for k in idx:
        idx[k].sort()
    print({k: (len(parts[k]), len(idx[k])) for k in idx}, "(writers, samples)")
    return idx, parts


def train_stats(samples, train_idx):
    xy = np.concatenate([samples[i].strokes[:, :2] for i in train_idx], 0)
    mean, std = xy.mean(0), xy.std(0) + 1e-6
    steps_per_char = float(np.median([len(samples[i].strokes) / max(1, len(samples[i].text)) for i in train_idx]))
    return {"mean": mean.astype(np.float32), "std": std.astype(np.float32), "steps_per_char": steps_per_char}


# --------------------------------------------------------------------------- datasets
class StrokeDataset(Dataset):
    """Returns target strokes (standardised), text ids, ONE disjoint style-reference sample of the same writer
    (k = 1), and the writer label (training writers only; -1 for unseen writers)."""

    def __init__(self, samples, idxs, vocab, stats, writer_map, train: bool, seed: int = 0):
        self.samples, self.idxs, self.vocab, self.stats = samples, list(idxs), vocab, stats
        self.writer_map, self.train = writer_map, train
        self.rng = np.random.default_rng(seed)
        self.by_writer = defaultdict(list)
        for i in self.idxs:
            self.by_writer[samples[i].writer].append(i)

    def __len__(self):
        return len(self.idxs)

    def _std(self, st):
        x = st.copy()
        x[:, :2] = (x[:, :2] - self.stats["mean"]) / self.stats["std"]
        return torch.from_numpy(x)

    def ref_index(self, i):
        c = [j for j in self.by_writer[self.samples[i].writer] if j != i]
        if not c:
            return i
        return int(self.rng.choice(c)) if self.train else c[0]

    def __getitem__(self, k):
        i = self.idxs[k]
        j = self.ref_index(i)
        s, r = self.samples[i], self.samples[j]
        return dict(strokes=self._std(s.strokes), text=torch.from_numpy(self.vocab.encode(s.text)),
                    ref_strokes=self._std(r.strokes), ref_text=torch.from_numpy(self.vocab.encode(r.text)),
                    writer=self.writer_map.get(s.writer, -1), idx=i, ref_idx=j)


def _pad(seqs, dim=None):
    L = max(len(s) for s in seqs)
    shape = (len(seqs), L) + tuple(seqs[0].shape[1:])
    out = torch.zeros(shape, dtype=seqs[0].dtype)
    mask = torch.zeros(len(seqs), L, dtype=torch.bool)
    for b, s in enumerate(seqs):
        out[b, :len(s)] = s
        mask[b, :len(s)] = True
    return out, mask


def collate(batch):
    st, st_m = _pad([b["strokes"] for b in batch])
    tx, tx_m = _pad([b["text"] for b in batch])
    rs, rs_m = _pad([b["ref_strokes"] for b in batch])
    rt, rt_m = _pad([b["ref_text"] for b in batch])
    return dict(strokes=st, stroke_mask=st_m, text=tx, text_mask=tx_m, ref_strokes=rs, ref_mask=rs_m,
                ref_text=rt, ref_text_mask=rt_m,
                writer=torch.tensor([b["writer"] for b in batch]),
                idx=torch.tensor([b["idx"] for b in batch]), ref_idx=torch.tensor([b["ref_idx"] for b in batch]))


def to_device(batch, dev):
    return {k: v.to(dev) for k, v in batch.items()}


def build_image_cache(samples, stats, cfg: Config, path: str):
    """GAN training images are RENDERED FROM THE SAME GROUND-TRUTH STROKES with the same rendering +
    canonicalisation function (no different image source), stored as uint8 at the largest GAN resolution."""
    import cv2
    from render import strokes_to_canonical
    R = max(cfg.gan_res_schedule)
    if os.path.exists(path):
        arr = np.load(path)["img"]
        if arr.shape == (len(samples), R, R):
            return arr
    arr = np.zeros((len(samples), R, R), np.uint8)
    for i, s in enumerate(samples):
        st = s.strokes.copy()
        st[:, :2] = (st[:, :2] - stats["mean"]) / stats["std"]          # same path as model outputs
        img = strokes_to_canonical(st, stats["mean"], stats["std"], cfg.canvas, cfg.margin, cfg.pen_width, cfg.ssaa, cfg.ink_threshold)
        if R != cfg.canvas:
            img = cv2.resize(img, (R, R), interpolation=cv2.INTER_AREA)
        arr[i] = np.round(img * 255).astype(np.uint8)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    np.savez_compressed(path, img=arr)
    return arr
