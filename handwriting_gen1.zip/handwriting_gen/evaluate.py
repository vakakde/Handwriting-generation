"""
Unified evaluation: identical test samples, identical text + style reference, identical rendering /
canonicalisation, identical metric code for LSTM, GAN and Transformer (manuscript Sec. 4.4).
"""
from __future__ import annotations
import os, time, json
import numpy as np
import torch

from config import Config
from data import collate, to_device
from render import strokes_to_canonical, raster_to_canonical
from metrics import (InceptionFeatures, frechet_distance, ssim_pair, OCREngine, stroke_continuity, cosine)
from models import build_model


class EvalContext:
    """Built ONCE: the N paired test samples, their real canonical images, reference images and features."""

    def __init__(self, cfg: Config, samples, ds_test, vocab, stats, dev, log=print):
        self.cfg, self.samples, self.ds, self.vocab, self.stats, self.dev = cfg, samples, ds_test, vocab, stats, dev
        rng = np.random.default_rng(cfg.eval_seed)
        n = min(cfg.n_eval, len(ds_test))
        if n < cfg.n_eval:
            log(f"[eval] only {len(ds_test)} test samples available (requested {cfg.n_eval})")
        self.pos = sorted(rng.choice(len(ds_test), n, replace=False).tolist())
        if n < 50:
            log(f"[eval] WARNING: FID is estimated from N={n} images/model (2048-d features) - extremely high variance; "
                "use a larger cfg.n_eval for any conclusion.")
        self.items = [ds_test[k] for k in self.pos]                          # deterministic reference (train=False)
        self.texts = [samples[it["idx"]].text for it in self.items]
        mk = lambda st: strokes_to_canonical(self._std(st), stats["mean"], stats["std"], cfg.canvas, cfg.margin, cfg.pen_width, cfg.ssaa, cfg.ink_threshold)
        self.real = [mk(samples[it["idx"]].strokes) for it in self.items]
        self.ref_img = [mk(samples[it["ref_idx"]].strokes) for it in self.items]
        self.feat = InceptionFeatures(cfg.fid_backend, str(dev))
        self.ocr = OCREngine(cfg.ocr_backend, str(dev))
        log(f"[eval] FID extractor pretrained={self.feat.pretrained} | OCR={self.ocr.name} | N={n}")
        self.f_real = self.feat(self.real)
        self.f_ref = self.feat(self.ref_img)
        self.ocr_real = float(np.nanmean([self.ocr.accuracy(im, t) for im, t in zip(self.real, self.texts)]))

    def _std(self, st):
        x = st.copy()
        x[:, :2] = (x[:, :2] - self.stats["mean"]) / self.stats["std"]
        return x


def _gen_length(cfg, stats, text_len):
    return int(np.clip(round(stats["steps_per_char"] * text_len), 4, cfg.max_seq_len))


@torch.no_grad()
def generate_image(name, model, item, ctx: EvalContext, gen, cache_t=None):
    """One output per sample: returns (canonical image, model-only inference time in seconds)."""
    cfg, stats, dev = ctx.cfg, ctx.stats, ctx.dev
    b = to_device(collate([item]), dev)
    L = _gen_length(cfg, stats, b["text"].size(1))
    if dev.type == "cuda":
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    if name == "lstm":
        out = model.generate(b["text"], L, cfg.sample_bias, gen, b["ref_strokes"], b["ref_text"])
    elif name.startswith("transformer"):
        out = model.generate(b["text"], b["ref_strokes"], L, cfg.sample_bias, gen)
    else:
        import torch.nn.functional as F
        ref = cache_t[b["ref_idx"].cpu()].to(dev).float().div(127.5).sub(1).unsqueeze(1)
        ref = F.interpolate(ref, size=(model.style_enc.res,) * 2, mode="area") if ref.size(-1) != model.style_enc.res else ref
        out = model.generate(b["text"], ref, gen)
    if dev.type == "cuda":
        torch.cuda.synchronize()
    dt = time.perf_counter() - t0
    if name == "gan":
        img = ((out[0, 0].float().cpu().numpy() + 1) / 2).clip(0, 1)            # ink-dark polarity, [0,1]
        img = raster_to_canonical(img, cfg.canvas, cfg.margin, cfg.ink_threshold)
    else:
        img = strokes_to_canonical(out[0].cpu().numpy(), stats["mean"], stats["std"], cfg.canvas, cfg.margin,
                                   cfg.pen_width, cfg.ssaa, cfg.ink_threshold)
    return img, dt


def evaluate_model(name, model, ctx: EvalContext, seed: int, img_cache=None, save_dir=None):
    model.eval()
    gen = torch.Generator(device=ctx.dev).manual_seed(1000 + seed)
    cache_t = torch.from_numpy(img_cache) if img_cache is not None else None
    imgs, times = [], []
    for it in ctx.items:
        im, dt = generate_image(name, model, it, ctx, gen, cache_t)
        imgs.append(im); times.append(dt)
    f_gen = ctx.feat(imgs)
    m = dict(
        model=name, seed=seed, n_eval=len(imgs),
        fid=frechet_distance(ctx.f_real, f_gen),
        ssim=float(np.mean([ssim_pair(g, r) for g, r in zip(imgs, ctx.real)])),
        ocr_acc=float(np.nanmean([ctx.ocr.accuracy(g, t) for g, t in zip(imgs, ctx.texts)])),
        inference_time_s=float(np.mean(times)),
        stroke_continuity=float(np.mean([stroke_continuity(g, r) for g, r in zip(imgs, ctx.real)])),
        style_sim=float(np.mean([cosine(a, b) for a, b in zip(f_gen, ctx.f_ref)])),
        fid_pretrained_extractor=bool(ctx.feat.pretrained), ocr_engine=ctx.ocr.name)
    if save_dir:
        os.makedirs(save_dir, exist_ok=True)
        np.savez_compressed(os.path.join(save_dir, f"{name}_seed{seed}.npz"),
                            gen=(np.stack(imgs) * 255).astype(np.uint8), texts=np.array(ctx.texts))
    return m


def save_real_samples(ctx: EvalContext, save_dir):
    os.makedirs(save_dir, exist_ok=True)
    np.savez_compressed(os.path.join(save_dir, "real.npz"), gen=(np.stack(ctx.real) * 255).astype(np.uint8),
                        ref=(np.stack(ctx.ref_img) * 255).astype(np.uint8), texts=np.array(ctx.texts))


def load_trained(name, cfg, vocab, stats, ckpt_path, dev):
    ck = torch.load(ckpt_path, map_location="cpu")
    m = build_model(name, cfg, vocab.size, stats, ck["n_writers"])
    m.load_state_dict(ck["state"])
    return m.to(dev).eval()
