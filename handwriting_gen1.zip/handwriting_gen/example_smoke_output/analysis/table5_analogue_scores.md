| model       | Visual Quality | Temporal Consistency | Style Control | Training Stability | Computational Efficiency | Overall Score |
|-------------|----------------|----------------------|---------------|--------------------|--------------------------|---------------|
| lstm        | 7.54           | 6.68                 | 10.00         | 10.00              | 1.65                     | 7.17          |
| gan         | 7.88           | 7.64                 | 10.00         | 2.67               | 10.00                    | 7.64          |
| transformer | 9.88           | 10.00                | 10.00         | 8.44               | 0.66                     | 7.80          |