| metric           | best_in_this_run | best_in_manuscript | agrees |
|------------------|------------------|--------------------|--------|
| fid              | lstm             | transformer        | False  |
| ssim             | transformer      | transformer        | True   |
| ocr_acc          | transformer      | transformer        | True   |
| train_time_h     | gan              | lstm               | False  |
| inference_time_s | gan              | gan                | True   |