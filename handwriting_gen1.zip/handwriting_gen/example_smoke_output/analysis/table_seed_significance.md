| metric           | pair                | mean_a    | mean_b    | welch_t | p         | cohen_d | p_holm   |
|------------------|---------------------|-----------|-----------|---------|-----------|---------|----------|
| fid              | lstm vs gan         | 0.141     | 0.2233    | -4.493  | 0.07164   | -4.493  | 0.7164   |
| fid              | lstm vs transformer | 0.141     | 0.1461    | -0.4479 | 0.6994    | -0.4479 | 1        |
| fid              | gan vs transformer  | 0.2233    | 0.1461    | 4.373   | 0.0881    | 4.373   | 0.7929   |
| ssim             | lstm vs gan         | 0.7701    | 0.6914    | 0.6493  | 0.6252    | 0.6493  | 1        |
| ssim             | lstm vs transformer | 0.7701    | 0.7833    | -0.3253 | 0.7765    | -0.3253 | 1        |
| ssim             | gan vs transformer  | 0.6914    | 0.7833    | -0.752  | 0.577     | -0.752  | 1        |
| ocr_acc          | lstm vs gan         | 0.025     | 0.07593   | -2.859  | 0.1404    | -2.859  | 1        |
| ocr_acc          | lstm vs transformer | 0.025     | 0.08935   | -1.136  | 0.4532    | -1.136  | 1        |
| ocr_acc          | gan vs transformer  | 0.07593   | 0.08935   | -0.2307 | 0.8515    | -0.2307 | 1        |
| inference_time_s | lstm vs gan         | 0.1409    | 0.004791  | 329.9   | 0.0005717 | 329.9   | 0.008575 |
| inference_time_s | lstm vs transformer | 0.1409    | 0.3628    | -15.4   | 0.04127   | -15.4   | 0.4539   |
| inference_time_s | gan vs transformer  | 0.004791  | 0.3628    | -24.83  | 0.02551   | -24.83  | 0.3316   |
| train_time_h     | lstm vs gan         | 0.0009571 | 0.0007671 | 1.562   | 0.3507    | 1.562   | 1        |
| train_time_h     | lstm vs transformer | 0.0009571 | 0.002299  | -10.54  | 0.03474   | -10.54  | 0.4169   |
| train_time_h     | gan vs transformer  | 0.0007671 | 0.002299  | -31.12  | 0.004465  | -31.12  | 0.06251  |