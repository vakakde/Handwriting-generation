| Aspect                      | Verified specification                                                                                     |
|-----------------------------|------------------------------------------------------------------------------------------------------------|
| Participants                | 53 (8 faculty + 10 PhD scholars + 35 postgraduate students = 53)                                           |
| Participant codes           | P001–P053                                                                                                  |
| Trials per participant      | K = 6                                                                                                      |
| Number of ratings (samples) | 53 × 6 × 3 = 954; found in ratings file: 954 samples (lstm: 318, gan: 318, transformer: 318)               |
| Items                       | 13 items (legibility:3, naturalness:3, style_consistency:4, overall_quality:3); 12402 item scores in total |
| Counterbalancing            | each of the 6 permutations appears K/6 = 1× per participant: VERIFIED (seed 2026)                          |
| Prompt selection            | 100 distinct prompts; used 3–4× each; no repeats within a participant: VERIFIED                            |
| Score range                 | 2–10 (scale 1–10)                                                                                          |
