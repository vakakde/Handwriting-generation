"""
Human evaluation: counterbalanced allocation, (optional) SIMULATED ratings for pipeline testing, and the full
statistical analysis described in the manuscript (Sec. 5.1):
    Friedman + Kendall's W per criterion, pairwise Wilcoxon signed-rank with Holm correction and matched-pairs
    rank-biserial correlation, Cronbach's alpha, Kruskal-Wallis across participant categories, chi-square on preferences.

REAL data format (what your raters produce) -> two CSV files
  ratings.csv      : participant_id, category, trial, model, item, score     (Supplement S3 format)
                     item in L1-L3, N1-N3, S1-S4, O1-O3 ; score 1..10
  prefs.csv        : participant_id, question (Q1-Q4), chosen_model

    python human_eval.py allocate  --out_dir runs/human
    python human_eval.py simulate  --out_dir runs/human        # SIMULATED data, for testing only
    python human_eval.py analyse   --ratings ratings.csv --prefs preferences.csv --out_dir runs/human
"""
from __future__ import annotations
import argparse, itertools, os
import numpy as np
import pandas as pd
from scipy import stats

MODELS = ["lstm", "gan", "transformer"]
CRITERIA = {"legibility": 3, "naturalness": 3, "style_consistency": 4, "overall_quality": 3}   # 13 items
QUESTIONS = ["readability", "naturalness", "style_consistency", "suitability"]
PERMS = list(itertools.permutations(MODELS))                                                    # 6 label permutations
# means used ONLY by the simulator: manuscript Table 4 (+ overall = mean of the three)
TABLE4 = {"lstm": (6.8, 6.3, 7.1), "gan": (7.9, 7.8, 7.3), "transformer": (8.7, 8.5, 8.2)}


# ----------------------------------------------------------------------------- allocation
CATEGORIES = ["Faculty", "PhD research scholars", "Postgraduate students"]
ITEMS = {"legibility": ["L1", "L2", "L3"], "naturalness": ["N1", "N2", "N3"],
         "style_consistency": ["S1", "S2", "S3", "S4"], "overall_quality": ["O1", "O2", "O3"]}      # 13 items
ITEM2CRIT = {i: c for c, v in ITEMS.items() for i in v}
Q_IDS = dict(zip(["Q1", "Q2", "Q3", "Q4"], ["readability", "naturalness", "style_consistency", "suitability"]))


def make_allocation(n_participants=53, K=6, n_prompts=100, seed=2026, category_counts=(8, 10, 35)):
    """Each participant rates K trials; in every trial the three models' outputs (same text + same writer reference)
    appear as anonymous A/B/C.  Each of the 6 model->label permutations is used K/6 times per participant (random order),
    so position/order effects are balanced.  Prompts are drawn WITHOUT replacement from the writer-disjoint test split."""
    assert K % 6 == 0, "K must be a multiple of 6 for full counterbalancing"
    rng = np.random.default_rng(seed)
    cats = [c for c, n in zip(CATEGORIES, category_counts) for _ in range(n)]
    assert len(cats) == n_participants
    rng.shuffle(cats)
    rows, usage = [], np.zeros(n_prompts)
    for p in range(n_participants):
        perms = [PERMS[i % 6] for i in range(K)]
        rng.shuffle(perms)
        # without replacement WITHIN a participant, least-used prompts first GLOBALLY (-> every prompt used ~equally often)
        prompts = np.argsort(usage + rng.random(n_prompts) * 0.5, kind="stable")[:K] if n_prompts >= K else rng.choice(n_prompts, K)
        usage[prompts] += 1
        prompts = rng.permutation(prompts)
        for t in range(K):
            rows.append(dict(participant_id=f"P{p + 1:03d}", category=cats[p], trial=t + 1, prompt_idx=int(prompts[t]),
                             label_A=perms[t][0], label_B=perms[t][1], label_C=perms[t][2]))
    return pd.DataFrame(rows)


# ------------------------------------------------------------------------------ simulation
def simulate_ratings(alloc: pd.DataFrame, seed=2026):
    """SIMULATED ratings (never report these as results!) centred on manuscript Table 4, to test the analysis code."""
    rng = np.random.default_rng(seed)
    pe = {p: rng.normal(0, 0.9) for p in alloc.participant_id.unique()}
    rows = []
    for _, r in alloc.iterrows():
        for label, col in zip("ABC", ["label_A", "label_B", "label_C"]):
            m = r[col]
            base = dict(zip(["legibility", "naturalness", "style_consistency"], TABLE4[m]))
            base["overall_quality"] = float(np.mean(TABLE4[m]))
            trial_eff = rng.normal(0, 0.5)
            for crit, item_ids in ITEMS.items():
                for it in item_ids:
                    v = base[crit] + pe[r.participant_id] + trial_eff + rng.normal(0, 0.6)
                    rows.append(dict(participant_id=r.participant_id, category=r.category, trial=r.trial, model=m,
                                     item=it, score=int(np.clip(round(v), 1, 10))))
    ratings = pd.DataFrame(rows)
    sc = ratings.groupby(["participant_id", "model"]).score.mean().unstack()
    prefs = []
    for p in sc.index:
        for q in Q_IDS:
            pr = np.exp(1.3 * sc.loc[p].reindex(MODELS).values)
            prefs.append(dict(participant_id=p, question=q, chosen_model=rng.choice(MODELS, p=pr / pr.sum())))
    return ratings, pd.DataFrame(prefs)


# -------------------------------------------------------------------------------- statistics
def holm(pvals):
    p = np.asarray(pvals, float); order = np.argsort(p); m = len(p)
    adj = np.empty(m); run = 0.0
    for rank, i in enumerate(order):
        run = max(run, (m - rank) * p[i]); adj[i] = min(1.0, run)
    return adj


def rank_biserial(x, y):
    d = np.asarray(x) - np.asarray(y); d = d[d != 0]
    if len(d) == 0:
        return 0.0
    rk = stats.rankdata(np.abs(d))
    return float((rk[d > 0].sum() - rk[d < 0].sum()) / rk.sum())


def cronbach_alpha(M):
    M = np.asarray(M, float); k = M.shape[1]
    return float(k / (k - 1) * (1 - M.var(0, ddof=1).sum() / M.sum(1).var(ddof=1)))


def normalise_inputs(ratings, prefs):
    r, p = ratings.copy(), prefs.copy()
    if "score" in r.columns:
        r = r.rename(columns={"score": "rating"})
    if "criterion" not in r.columns:
        r["criterion"] = r["item"].map(ITEM2CRIT)
    if "chosen_model" in p.columns:
        p = p.rename(columns={"chosen_model": "preferred_model"})
    p["question"] = p["question"].replace(Q_IDS)
    return r, p


def analyse(ratings: pd.DataFrame, prefs: pd.DataFrame):
    ratings, prefs = normalise_inputs(ratings, prefs)
    out = {}
    sample = ratings.groupby(["participant_id", "category", "trial", "model", "criterion"]).rating.mean().reset_index()
    part = sample.groupby(["participant_id", "category", "model", "criterion"]).rating.mean().reset_index()   # unit = participant
    # Table 4
    t4 = part.groupby(["criterion", "model"]).rating.agg(["mean", "std"]).reset_index()
    t4["mean_sd"] = t4.apply(lambda r: f"{r['mean']:.1f} ± {r['std']:.1f}", axis=1)
    out["table4"] = t4.pivot(index="model", columns="criterion", values="mean_sd").reindex(MODELS)
    out["table4_numeric"] = t4
    fr, pw = [], []
    for crit in CRITERIA:
        W = part[part.criterion == crit].pivot(index="participant_id", columns="model", values="rating")[MODELS]
        chi, p = stats.friedmanchisquare(*[W[m] for m in MODELS])
        n = len(W)
        fr.append(dict(criterion=crit, n=n, chi2=chi, df=2, p=p, kendall_W=chi / (n * (len(MODELS) - 1))))
        rows = []
        for a, b in itertools.combinations(MODELS, 2):
            try:
                st, pv = stats.wilcoxon(W[a], W[b], alternative="two-sided")
            except ValueError:                                   # all differences zero
                st, pv = 0.0, 1.0
            rows.append(dict(criterion=crit, pair=f"{a} vs {b}", W=st, p=pv, r_rb=rank_biserial(W[a], W[b])))
        adj = holm([r["p"] for r in rows])
        for r, ap in zip(rows, adj):
            r["p_holm"] = ap; pw.append(r)
    out["friedman"], out["pairwise"] = pd.DataFrame(fr), pd.DataFrame(pw)
    # Cronbach alpha (items of a criterion, rows = rated samples)
    ca = []
    for crit in CRITERIA:
        M = ratings[ratings.criterion == crit].pivot_table(index=["participant_id", "trial", "model"], columns="item", values="rating")
        ca.append(dict(criterion=crit, n_items=M.shape[1], alpha=cronbach_alpha(M.values)))
    out["cronbach"] = pd.DataFrame(ca)
    # participant categories (Kruskal-Wallis on participant means averaged over models)
    kw = []
    for crit in CRITERIA:
        g = part[part.criterion == crit].groupby(["participant_id", "category"]).rating.mean().reset_index()
        groups = [v.rating.values for _, v in g.groupby("category")]
        h, p = stats.kruskal(*groups)
        kw.append(dict(criterion=crit, H=h, p=p))
    out["kruskal"] = pd.DataFrame(kw)
    # preferences
    pr = []
    for q in QUESTIONS:
        c = prefs[prefs.question == q].preferred_model.value_counts().reindex(MODELS).fillna(0).astype(int)
        chi, p = stats.chisquare(c.values)
        pr.append(dict(question=q, **{m: int(c[m]) for m in MODELS}, chi2=chi, p=p))
    out["preferences"] = pd.DataFrame(pr)
    return out


def write_report(res, out_dir, simulated):
    os.makedirs(out_dir, exist_ok=True)
    for k, v in res.items():
        v.to_csv(os.path.join(out_dir, f"human_{k}.csv"), index=k == "table4")
    with open(os.path.join(out_dir, "human_report.txt"), "w") as f:
        if simulated:
            f.write("*** SIMULATED RATINGS - FOR PIPELINE TESTING ONLY. NOT EVIDENCE. ***\n\n")
        for k in ["table4", "friedman", "pairwise", "cronbach", "kruskal", "preferences"]:
            f.write(f"== {k} ==\n{res[k].to_string()}\n\n")
    return os.path.join(out_dir, "human_report.txt")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["allocate", "simulate", "analyse"])
    ap.add_argument("--out_dir", default="runs/human")
    ap.add_argument("--ratings"); ap.add_argument("--prefs")
    ap.add_argument("--n_prompts", type=int, default=100)
    a = ap.parse_args()
    os.makedirs(a.out_dir, exist_ok=True)
    if a.cmd == "allocate":
        make_allocation(n_prompts=a.n_prompts).to_csv(os.path.join(a.out_dir, "allocation.csv"), index=False)
    elif a.cmd == "simulate":
        al = make_allocation(n_prompts=a.n_prompts); al.to_csv(os.path.join(a.out_dir, "allocation.csv"), index=False)
        r, p = simulate_ratings(al)
        r.to_csv(os.path.join(a.out_dir, "SIMULATED_ratings.csv"), index=False); p.to_csv(os.path.join(a.out_dir, "SIMULATED_prefs.csv"), index=False)
        print(write_report(analyse(r, p), a.out_dir, True))
    else:
        print(write_report(analyse(pd.read_csv(a.ratings), pd.read_csv(a.prefs)), a.out_dir, False))


if __name__ == "__main__":
    main()
