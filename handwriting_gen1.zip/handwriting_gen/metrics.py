"""
Evaluation metrics on CANONICAL images (manuscript Sec. 4.4 (v)):
  FID  : Inception-v3 pool3 (2048-d) features, grayscale replicated to 3 channels, resized to 299x299.
  SSIM : paired, Gaussian window 11x11, sigma 1.5, data range 1.
  OCR  : one fixed handwriting recogniser; accuracy = max(0, 1 - CER).
plus two helper metrics used by the comparison analysis:
  stroke-continuity (connected-component ratio) and style similarity (cosine in Inception space).
"""
from __future__ import annotations
import warnings
import numpy as np
import cv2
import torch
import torch.nn as nn
import torch.nn.functional as F
from skimage.metrics import structural_similarity


# --------------------------------------------------------------------------------- FID
class InceptionFeatures:
    def __init__(self, backend="auto", device="cpu", seed=0):
        import torchvision
        self.device, self.pretrained = torch.device(device), False
        m = None
        if backend in ("auto", "inception"):
            try:
                m = torchvision.models.inception_v3(weights=torchvision.models.Inception_V3_Weights.IMAGENET1K_V1)
                self.pretrained = True
            except Exception as e:                                           # no internet / weights unavailable
                if backend == "inception":
                    raise
                warnings.warn(f"Pretrained Inception-v3 unavailable ({type(e).__name__}); using a RANDOM feature extractor. "
                              "FID values are then only valid for pipeline testing, NOT comparable to published FID.")
        if m is None:
            g = torch.random.fork_rng()
            with g:
                torch.manual_seed(seed)
                m = torchvision.models.inception_v3(weights=None, aux_logits=True, init_weights=True, transform_input=False)
        m.fc = nn.Identity()
        self.m = m.eval().to(self.device)
        self.mean = torch.tensor([0.485, 0.456, 0.406], device=self.device).view(1, 3, 1, 1)
        self.std = torch.tensor([0.229, 0.224, 0.225], device=self.device).view(1, 3, 1, 1)

    @torch.no_grad()
    def __call__(self, imgs, bs=8):
        feats = []
        for i in range(0, len(imgs), bs):
            x = torch.from_numpy(np.stack(imgs[i:i + bs])).float().unsqueeze(1).to(self.device)     # (b,1,H,W) in [0,1]
            x = x.repeat(1, 3, 1, 1)
            x = F.interpolate(x, size=(299, 299), mode="bilinear", align_corners=False)
            f = self.m((x - self.mean) / self.std).cpu().numpy()
            if not self.pretrained:                      # random extractor: L2-normalise (x10) to keep magnitudes sane -> "pseudo-FID"
                f = 10.0 * f / (np.linalg.norm(f, axis=1, keepdims=True) + 1e-12)
            feats.append(f)
        return np.concatenate(feats, 0).astype(np.float64)


def frechet_distance(f1: np.ndarray, f2: np.ndarray) -> float:
    """FID = ||mu_r - mu_g||^2 + Tr(S_r + S_g - 2 (S_r S_g)^(1/2)).
    With few samples (N << 2048, e.g. the manuscript's N = 5) the covariances are rank-deficient; the matrix
    square-root trace is then computed EXACTLY and stably as the nuclear norm of A B^T (A, B = centred features):
    Tr (S_r S_g)^(1/2) = ||A B^T||_* / sqrt((n1-1)(n2-1))."""
    n1, n2, d = len(f1), len(f2), f1.shape[1]
    mu1, mu2 = f1.mean(0), f2.mean(0)
    A, B = f1 - mu1, f2 - mu2
    t1 = (A ** 2).sum() / max(n1 - 1, 1)
    t2 = (B ** 2).sum() / max(n2 - 1, 1)
    if min(n1, n2) <= d // 2 and n1 > 1 and n2 > 1:
        tr_sqrt = np.linalg.svd(A @ B.T, compute_uv=False).sum() / np.sqrt((n1 - 1) * (n2 - 1))
    else:
        from scipy import linalg
        s1, s2 = np.cov(f1, rowvar=False), np.cov(f2, rowvar=False)
        cm, _ = linalg.sqrtm(s1.dot(s2), disp=False)
        if not np.isfinite(cm).all():
            off = np.eye(d) * 1e-6
            cm = linalg.sqrtm((s1 + off).dot(s2 + off))
        tr_sqrt = np.trace(cm.real)
    return float(((mu1 - mu2) ** 2).sum() + t1 + t2 - 2 * tr_sqrt)


# -------------------------------------------------------------------------------- SSIM
def ssim_pair(a: np.ndarray, b: np.ndarray) -> float:
    return float(structural_similarity(a, b, data_range=1.0, gaussian_weights=True, sigma=1.5,
                                       use_sample_covariance=False, win_size=11))


# --------------------------------------------------------------------------------- OCR
def levenshtein(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def char_accuracy(pred: str, ref: str) -> float:
    """1 - CER, CER = Levenshtein(pred, ref) / len(ref); clipped at 0."""
    return max(0.0, 1.0 - levenshtein(pred.strip(), ref.strip()) / max(1, len(ref.strip())))


class OCREngine:
    """One recogniser applied UNCHANGED (no fine-tuning, identical decoding) to all models.
    auto: TrOCR (microsoft/trocr-base-handwritten) if `transformers` is installed, else Tesseract, else disabled."""

    def __init__(self, backend="auto", device="cpu"):
        self.name, self.fn = "none", None
        if backend in ("auto", "trocr"):
            try:
                from transformers import TrOCRProcessor, VisionEncoderDecoderModel
                from PIL import Image
                proc = TrOCRProcessor.from_pretrained("microsoft/trocr-base-handwritten")
                mdl = VisionEncoderDecoderModel.from_pretrained("microsoft/trocr-base-handwritten").to(device).eval()

                def fn(img01):
                    im = Image.fromarray((img01 * 255).astype(np.uint8)).convert("RGB")
                    pv = proc(images=im, return_tensors="pt").pixel_values.to(device)
                    with torch.no_grad():
                        ids = mdl.generate(pv, num_beams=1, max_new_tokens=64)          # greedy, identical for all models
                    return proc.batch_decode(ids, skip_special_tokens=True)[0]
                self.name, self.fn = "trocr-base-handwritten", fn
                return
            except Exception as e:
                if backend == "trocr":
                    raise
        if backend in ("auto", "tesseract"):
            try:
                import pytesseract
                from PIL import Image
                ver = pytesseract.get_tesseract_version()
                self.name = f"tesseract-{ver}"
                self.fn = lambda img01: pytesseract.image_to_string(Image.fromarray((img01 * 255).astype(np.uint8)), config="--psm 7").strip()
                return
            except Exception:
                pass
        warnings.warn("No OCR backend available -> OCR accuracy will be NaN (pip install transformers, or install tesseract).")

    def accuracy(self, img01, ref_text):
        if self.fn is None:
            return float("nan")
        return char_accuracy(self.fn(img01), ref_text)


# --------------------------------------------------------------- helper (analysis) metrics
def n_components(img01: np.ndarray, thr=0.5) -> int:
    n, _ = cv2.connectedComponents((img01 < thr).astype(np.uint8), connectivity=8)
    return n - 1


def stroke_continuity(gen, real) -> float:
    """1 / (1 + |log((cc_gen+1)/(cc_real+1))|): 1 = same fragmentation as the real handwriting."""
    return float(1.0 / (1.0 + abs(np.log((n_components(gen) + 1) / (n_components(real) + 1)))))


def cosine(a, b):
    return float(a @ b / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-12))
