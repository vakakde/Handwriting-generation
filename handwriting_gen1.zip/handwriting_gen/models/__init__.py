from __future__ import annotations
from .lstm import GravesLSTM
from .transformer import StrokeTransformer
from .gan import GANBundle

MODEL_NAMES = ["lstm", "gan", "transformer"]


def build_model(name, cfg, vocab_size, stats, n_writers):
    if name == "lstm":
        return GravesLSTM(vocab_size, cfg.lstm_hidden, cfg.lstm_layers, cfg.n_mix, cfg.window_K, cfg.char_emb, cfg.lstm_dropout)
    if name in ("transformer", "transformer_noattn"):
        return StrokeTransformer(vocab_size, stats["mean"], stats["std"], n_writers, cfg.tf_d_model, cfg.tf_heads,
                                 cfg.tf_layers, cfg.tf_ff, cfg.tf_dropout, cfg.tf_style_layers, cfg.n_mix,
                                 cfg.tf_pos_scale, use_self_attention=(name == "transformer"))
    if name == "gan":
        return GANBundle(vocab_size, n_writers, cfg.gan_z_dim, cfg.gan_text_dim, cfg.gan_style_dim,
                         cfg.gan_base_ch, max(cfg.gan_res_schedule))
    raise ValueError(name)


def count_params(m):
    return sum(p.numel() for p in m.parameters() if p.requires_grad)
