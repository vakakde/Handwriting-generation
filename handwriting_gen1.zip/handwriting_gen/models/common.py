"""Mixture-density output head shared by the LSTM and the Transformer (identical sampling for both)."""
from __future__ import annotations
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class MDNHead(nn.Module):
    """Outputs, per step: pen-lift logit e, and for M bivariate Gaussians: pi, mu(2), sigma(2), rho.
    -> 6M + 1 numbers.  P(x_{t+1}) = sum_k pi_k N(x; mu_k, Sigma_k)   (manuscript Eq. I, VIII-X)."""

    def __init__(self, d_in: int, n_mix: int = 20):
        super().__init__()
        self.M = n_mix
        self.proj = nn.Linear(d_in, 6 * n_mix + 1)

    def forward(self, h):
        return self.proj(h)


def split_params(out, M, bias: float = 0.0):
    e = out[..., 0]
    pi, m1, m2, s1, s2, rho = out[..., 1:].split(M, dim=-1)
    log_pi = F.log_softmax(pi * (1.0 + bias), dim=-1)           # Graves' bias: sharper mixture weights ...
    s1 = torch.exp((s1 - bias).clamp(max=5.0)).clamp(min=1e-3)  # ... and smaller variances
    s2 = torch.exp((s2 - bias).clamp(max=5.0)).clamp(min=1e-3)
    rho = torch.tanh(rho) * 0.999
    return e, log_pi, m1, m2, s1, s2, rho


def mdn_nll(out, target, mask, M):
    """Mean negative log-likelihood of (dx, dy) under the mixture + BCE of the pen-lift flag.
    target (B,T,3), mask (B,T) bool."""
    e, log_pi, m1, m2, s1, s2, rho = split_params(out, M, 0.0)
    x, y, p = target[..., 0:1], target[..., 1:2], target[..., 2]
    z = ((x - m1) / s1) ** 2 + ((y - m2) / s2) ** 2 - 2 * rho * (x - m1) * (y - m2) / (s1 * s2)
    one_m = 1 - rho ** 2
    log_n = -z / (2 * one_m) - torch.log(2 * math.pi * s1 * s2 * torch.sqrt(one_m))
    nll_xy = -torch.logsumexp(log_pi + log_n, dim=-1)
    nll_p = F.binary_cross_entropy_with_logits(e, p, reduction="none")
    m = mask.float()
    return ((nll_xy + nll_p) * m).sum() / m.sum().clamp(min=1.0)


@torch.no_grad()
def sample_mdn(out, M, bias: float = 0.0, generator=None):
    """out (B, 6M+1) for ONE time step -> sampled (dx, dy, p) of shape (B,3)."""
    e, log_pi, m1, m2, s1, s2, rho = split_params(out, M, bias)
    k = torch.multinomial(log_pi.exp(), 1, generator=generator)
    g = lambda t: t.gather(-1, k).squeeze(-1)
    m1, m2, s1, s2, rho = g(m1), g(m2), g(s1), g(s2), g(rho)
    z1 = torch.randn(m1.shape, generator=generator, device=m1.device)
    z2 = torch.randn(m1.shape, generator=generator, device=m1.device)
    dx = m1 + s1 * z1
    dy = m2 + s2 * (rho * z1 + torch.sqrt(1 - rho ** 2) * z2)
    pen = (torch.rand(m1.shape, generator=generator, device=m1.device) < torch.sigmoid(e)).float()
    return torch.stack([dx, dy, pen], -1)
