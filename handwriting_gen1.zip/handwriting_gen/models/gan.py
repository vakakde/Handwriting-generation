"""
Conditional progressive GAN for handwriting IMAGES (manuscript Sec. 3.3 / 4.2).

* Generator : transposed convolutions + spectral normalisation, progressive growth (fade-in) 64 -> 512 px.
* Discriminator : spectral norm, self-attention layer (SAGAN) at 16x16, gradient-penalty regularisation (R1).
* Conditioning : text c (BiGRU text encoder) and writer style (CNN style encoder on ONE reference image, trained
  with writer-ID labels; no label at test time).  G receives [z ; text ; style]; D uses a projection of [text ; style].
* L_G = -E[log D(G(z,c))] + lambda * L_rec ;  L_D = -E[log D(x)] - E[log(1 - D(G(z,c)))]  (+ R1).
  (softplus form == the logistic losses of Eq. XI / XII)
Images: [-1, 1], ink = -1 (dark), paper = +1.
"""
from __future__ import annotations
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils import spectral_norm as SN


def _ch(i, base):                        # channels at resolution 4 * 2^i
    return max(8, base >> max(0, i - 3))


class SelfAttention2d(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.q, self.k = SN(nn.Conv2d(c, max(1, c // 8), 1)), SN(nn.Conv2d(c, max(1, c // 8), 1))
        self.v, self.o = SN(nn.Conv2d(c, max(1, c // 2), 1)), SN(nn.Conv2d(max(1, c // 2), c, 1))
        self.gamma = nn.Parameter(torch.zeros(1))

    def forward(self, x):
        B, C, H, W = x.shape
        q, k, v = self.q(x).flatten(2), self.k(x).flatten(2), self.v(x).flatten(2)
        a = torch.softmax(torch.bmm(q.transpose(1, 2), k) / math.sqrt(q.size(1)), -1)      # (B,N,N)
        o = torch.bmm(v, a.transpose(1, 2)).view(B, -1, H, W)
        return x + self.gamma * self.o(o)


class TextEncoder(nn.Module):
    def __init__(self, vocab, d):
        super().__init__()
        self.emb = nn.Embedding(vocab, 64, padding_idx=0)
        self.rnn = nn.GRU(64, d // 2, batch_first=True, bidirectional=True)
        self.out = nn.Linear(d, d)

    def forward(self, text, mask):
        h, _ = self.rnn(self.emb(text))
        m = mask.unsqueeze(-1).float()
        return self.out((h * m).sum(1) / m.sum(1).clamp(min=1))


class ImageStyleEncoder(nn.Module):
    def __init__(self, d, n_writers, res=64, base=32):
        super().__init__()
        self.res = res
        layers, c, r = [], 1, res
        for i in range(4):
            layers += [SN(nn.Conv2d(c, base * 2 ** i, 4, 2, 1)), nn.LeakyReLU(0.2)]
            c = base * 2 ** i
        self.cnn = nn.Sequential(*layers)
        self.fc = nn.Linear(c, d)
        self.cls = nn.Linear(d, max(1, n_writers))

    def forward(self, img):                                  # img (B,1,R,R) in [-1,1]
        x = F.interpolate(img, size=(self.res, self.res), mode="area") if img.size(-1) != self.res else img
        v = self.fc(self.cnn(x).mean((2, 3)))
        return v, self.cls(v)


class GBlock(nn.Module):
    def __init__(self, cin, cout):
        super().__init__()
        self.net = nn.Sequential(SN(nn.ConvTranspose2d(cin, cout, 4, 2, 1)), nn.BatchNorm2d(cout), nn.LeakyReLU(0.2),
                                 SN(nn.Conv2d(cout, cout, 3, 1, 1)), nn.BatchNorm2d(cout), nn.LeakyReLU(0.2))

    def forward(self, x):
        return self.net(x)


class Generator(nn.Module):
    def __init__(self, z_dim, cond_dim, base_ch, max_res):
        super().__init__()
        self.nb = int(math.log2(max_res // 4))
        self.ch = [_ch(i, base_ch) for i in range(self.nb + 1)]
        self.fc = nn.Linear(z_dim + cond_dim, self.ch[0] * 16)
        self.blocks = nn.ModuleList([GBlock(self.ch[i], self.ch[i + 1]) for i in range(self.nb)])
        self.to_gray = nn.ModuleList([nn.Conv2d(self.ch[i], 1, 1) for i in range(self.nb + 1)])

    def forward(self, z, cond, res, alpha=1.0):
        n = int(math.log2(res // 4))
        x = F.leaky_relu(self.fc(torch.cat([z, cond], 1)).view(z.size(0), self.ch[0], 4, 4), 0.2)
        prev = x
        for i in range(n):
            prev = x
            x = self.blocks[i](x)
        out = self.to_gray[n](x)
        if alpha < 1.0 and n > 0:                                       # progressive fade-in
            out = alpha * out + (1 - alpha) * F.interpolate(self.to_gray[n - 1](prev), scale_factor=2, mode="nearest")
        return torch.tanh(out)


class DBlock(nn.Module):
    def __init__(self, cin, cout, attn):
        super().__init__()
        self.net = nn.Sequential(SN(nn.Conv2d(cin, cin, 3, 1, 1)), nn.LeakyReLU(0.2),
                                 SN(nn.Conv2d(cin, cout, 3, 1, 1)), nn.LeakyReLU(0.2), nn.AvgPool2d(2))
        self.attn = SelfAttention2d(cout) if attn else None

    def forward(self, x):
        x = self.net(x)
        return self.attn(x) if self.attn is not None else x


class Discriminator(nn.Module):
    def __init__(self, cond_dim, base_ch, max_res):
        super().__init__()
        self.nb = int(math.log2(max_res // 4))
        ch = [_ch(i, base_ch) for i in range(self.nb + 1)]
        self.from_gray = nn.ModuleList([SN(nn.Conv2d(1, ch[i], 1)) for i in range(self.nb + 1)])
        self.blocks = nn.ModuleList([DBlock(ch[i + 1], ch[i], attn=(i == 2)) for i in range(self.nb)])   # block i outputs res 4*2^i
        self.final = SN(nn.Conv2d(ch[0], ch[0], 4, 1, 0))
        self.lin = SN(nn.Linear(ch[0], 1))
        self.proj = SN(nn.Linear(cond_dim, ch[0]))                       # projection conditioning

    def forward(self, img, cond, res, alpha=1.0):
        n = int(math.log2(res // 4))
        x = F.leaky_relu(self.from_gray[n](img), 0.2)
        for i in reversed(range(n)):
            x = self.blocks[i](x)
            if alpha < 1.0 and i == n - 1 and n > 0:                     # fade-in from the lower-resolution path
                skip = F.leaky_relu(self.from_gray[n - 1](F.avg_pool2d(img, 2)), 0.2)
                x = alpha * x + (1 - alpha) * skip
        f = F.leaky_relu(self.final(x), 0.2).flatten(1)
        return self.lin(f).squeeze(1) + (self.proj(cond) * f).sum(1)


class GANBundle(nn.Module):
    def __init__(self, vocab, n_writers, z_dim, text_dim, style_dim, base_ch, max_res):
        super().__init__()
        self.z_dim, self.max_res = z_dim, max_res
        self.text_enc = TextEncoder(vocab, text_dim)
        self.style_enc = ImageStyleEncoder(style_dim, n_writers, res=min(64, max_res))
        self.G = Generator(z_dim, text_dim + style_dim, base_ch, max_res)
        self.D = Discriminator(text_dim + style_dim, base_ch, max_res)

    def cond(self, text, text_mask, ref_img):
        s, logits = self.style_enc(ref_img)
        return torch.cat([self.text_enc(text, text_mask), s], 1), logits

    @torch.no_grad()
    def generate(self, text, ref_img, generator=None):
        c, _ = self.cond(text, text > 0, ref_img)
        z = torch.randn(text.size(0), self.z_dim, generator=generator, device=text.device)
        return self.G(z, c, self.max_res, 1.0)                           # (B,1,R,R) in [-1,1]
