"""
LSTM-RNN handwriting model (Graves 2013): 3 stacked LSTM layers (256 units), Gaussian attention window over
the character sequence, 20-component bivariate-Gaussian mixture density output + Bernoulli pen state.
Dropout 0.2.  Style conditioning (k = 1 reference sample) is done by Graves-style PRIMING: the reference strokes
and its text are fed through the network before the target text is generated.   (manuscript Sec. 3.2, 4.4 (iii))
"""
from __future__ import annotations
import torch
import torch.nn as nn
from .common import MDNHead, sample_mdn


class GravesLSTM(nn.Module):
    def __init__(self, vocab_size, hidden=256, n_layers=3, n_mix=20, K=10, emb=64, dropout=0.2):
        super().__init__()
        self.hidden, self.n_layers, self.K, self.emb_dim, self.M = hidden, n_layers, K, emb, n_mix
        self.emb = nn.Embedding(vocab_size, emb, padding_idx=0)               # character embedding layer
        self.cell1 = nn.LSTMCell(3 + emb, hidden)                              # layer 1 (input: x_{t-1}, w_{t-1})
        self.win = nn.Linear(hidden, 3 * K)                                    # attention-window parameters
        self.upper = nn.ModuleList([nn.LSTM(3 + hidden + emb, hidden, batch_first=True)
                                    for _ in range(n_layers - 1)])             # layers 2..L (input: x, h_{l-1}, w_t)
        self.drop = nn.Dropout(dropout)
        self.mdn = MDNHead(hidden * n_layers, n_mix)                           # skip connections from all layers

    # ------------------------------------------------------------ attention window
    def _window(self, h1, kappa, te, mask):
        a, b, k = self.win(h1).chunk(3, dim=-1)
        alpha = torch.exp(a.clamp(max=5)).unsqueeze(-1)                        # (B,K,1)
        beta = torch.exp(b.clamp(max=5)).unsqueeze(-1)
        kappa = kappa + torch.exp(k.clamp(max=5)) / 25.0                       # monotone location
        u = torch.arange(1, te.size(1) + 1, device=te.device, dtype=te.dtype).view(1, 1, -1)
        phi = (alpha * torch.exp(-beta * (kappa.unsqueeze(-1) - u) ** 2)).sum(1)   # (B,U)
        phi = phi * mask.float()
        w = (phi.unsqueeze(-1) * te).sum(1)                                    # (B,emb)
        return w, kappa, phi

    # --------------------------------------------------------- teacher-forced pass
    def forward(self, x, text, text_mask):
        B, T, _ = x.shape
        x_in = torch.cat([x.new_zeros(B, 1, 3), x[:, :-1]], 1)
        te = self.emb(text)
        h = x.new_zeros(B, self.hidden); c = x.new_zeros(B, self.hidden)
        kappa = x.new_zeros(B, self.K); w = x.new_zeros(B, self.emb_dim)
        h1s, ws = [], []
        for t in range(T):
            h, c = self.cell1(torch.cat([x_in[:, t], w], -1), (h, c))
            w, kappa, _ = self._window(h, kappa, te, text_mask)
            h1s.append(h); ws.append(w)
        H, W = torch.stack(h1s, 1), torch.stack(ws, 1)
        hs, prev = [self.drop(H)], self.drop(H)
        for layer in self.upper:
            o, _ = layer(torch.cat([x_in, prev, W], -1))
            prev = self.drop(o)
            hs.append(prev)
        return self.mdn(torch.cat(hs, -1))

    # -------------------------------------------------------------- generation
    def _init_state(self, B, dev):
        z = lambda *s: torch.zeros(*s, device=dev)
        return dict(h=z(B, self.hidden), c=z(B, self.hidden), kappa=z(B, self.K), w=z(B, self.emb_dim),
                    up=[None] * len(self.upper))

    def _step(self, x_prev, st, te, mask):
        st["h"], st["c"] = self.cell1(torch.cat([x_prev, st["w"]], -1), (st["h"], st["c"]))
        st["w"], st["kappa"], phi = self._window(st["h"], st["kappa"], te, mask)
        hs, prev = [st["h"]], st["h"]
        for i, layer in enumerate(self.upper):
            o, st["up"][i] = layer(torch.cat([x_prev, prev, st["w"]], -1).unsqueeze(1), st["up"][i])
            prev = o[:, 0]
            hs.append(prev)
        return self.mdn(torch.cat(hs, -1)), phi

    @torch.no_grad()
    def generate(self, text, length, bias=0.5, generator=None, prime_strokes=None, prime_text=None):
        """text (1,U) ids.  prime_* : style reference (k=1) used to prime the network.  Returns (1,length,3), standardised."""
        dev = text.device
        full = torch.cat([prime_text, text], 1) if prime_text is not None else text
        mask = full > 0
        te = self.emb(full)
        st = self._init_state(1, dev)
        x_prev = torch.zeros(1, 3, device=dev)
        if prime_strokes is not None:
            for t in range(prime_strokes.size(1)):
                self._step(x_prev, st, te, mask)
                x_prev = prime_strokes[:, t]
        outs = []
        for _ in range(length):
            out, _ = self._step(x_prev, st, te, mask)
            x_prev = sample_mdn(out, self.M, bias, generator)
            outs.append(x_prev)
        return torch.stack(outs, 1)
