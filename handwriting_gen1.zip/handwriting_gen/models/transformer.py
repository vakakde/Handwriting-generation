"""
Transformer handwriting model: text encoder (self-attention), style encoder (self-attention over ONE reference
stroke sequence), autoregressive decoder with masked self-attention + cross-attention to [style tokens ; text tokens],
shared 20-component MDN head.  6 layers, 8 heads, d_model 512, d_ff 2048 (manuscript Sec. 4.2).

"Positional encodings expanded for two-dimensional stroke information": every stroke token receives
(i) a sinusoidal encoding of its time index and (ii) a sinusoidal encoding of the absolute (x, y) pen position
(cumulative sum of the offsets).   `use_self_attention=False` reproduces the ablation of Sec. 5.1.2
(decoder self-attention sub-layers removed).
"""
from __future__ import annotations
import math
import torch
import torch.nn as nn
from .common import MDNHead, sample_mdn


def sinusoid_table(L, d):
    pos = torch.arange(L).float().unsqueeze(1)
    div = torch.exp(torch.arange(0, d, 2).float() * (-math.log(10000.0) / d))
    pe = torch.zeros(L, d)
    pe[:, 0::2], pe[:, 1::2] = torch.sin(pos * div), torch.cos(pos * div)
    return pe


def abs_pos_encoding(xy, d):
    """xy (B,T,2) (scaled) -> (B,T,d): [sin/cos(x f), sin/cos(y f)] with geometric frequencies."""
    q = d // 4
    f = torch.exp(torch.arange(q, device=xy.device).float() * (-math.log(10000.0) / q))
    ax = xy[..., 0:1] * f
    ay = xy[..., 1:2] * f
    return torch.cat([ax.sin(), ax.cos(), ay.sin(), ay.cos()], -1)


class DecLayer(nn.Module):
    def __init__(self, d, h, ff, drop, use_sa=True):
        super().__init__()
        self.sa = nn.MultiheadAttention(d, h, dropout=drop, batch_first=True) if use_sa else None
        self.ca = nn.MultiheadAttention(d, h, dropout=drop, batch_first=True)
        self.ff = nn.Sequential(nn.Linear(d, ff), nn.GELU(), nn.Dropout(drop), nn.Linear(ff, d))
        self.n1, self.n2, self.n3 = nn.LayerNorm(d), nn.LayerNorm(d), nn.LayerNorm(d)
        self.drop = nn.Dropout(drop)

    def forward(self, x, mem, causal, mem_kpm):
        if self.sa is not None:
            y = self.n1(x)
            x = x + self.drop(self.sa(y, y, y, attn_mask=causal, need_weights=False)[0])
        y = self.n2(x)
        x = x + self.drop(self.ca(y, mem, mem, key_padding_mask=mem_kpm, need_weights=False)[0])
        return x + self.drop(self.ff(self.n3(x)))


class StrokeTransformer(nn.Module):
    def __init__(self, vocab_size, mean, std, n_writers, d_model=512, nhead=8, n_layers=6, d_ff=2048,
                 dropout=0.1, style_layers=2, n_mix=20, pos_scale=0.01, use_self_attention=True, max_len=4096):
        super().__init__()
        self.d, self.M, self.pos_scale = d_model, n_mix, pos_scale
        self.register_buffer("mu", torch.as_tensor(mean, dtype=torch.float32))
        self.register_buffer("sd", torch.as_tensor(std, dtype=torch.float32))
        self.register_buffer("pe", sinusoid_table(max_len, d_model), persistent=False)
        # text encoder
        self.char_emb = nn.Embedding(vocab_size, d_model, padding_idx=0)
        enc = lambda n: nn.TransformerEncoder(nn.TransformerEncoderLayer(d_model, nhead, d_ff, dropout, batch_first=True,
                                                                         norm_first=True, activation="gelu"), n,
                                              enable_nested_tensor=False)
        self.text_enc = enc(n_layers)
        # style encoder (one reference sample) + writer classifier (writer labels only used for training)
        self.style_in = nn.Linear(3, d_model)
        self.style_enc = enc(style_layers)
        self.style_cls = nn.Linear(d_model, max(1, n_writers))
        # decoder
        self.in_proj = nn.Linear(3, d_model)
        self.dec = nn.ModuleList([DecLayer(d_model, nhead, d_ff, dropout, use_self_attention) for _ in range(n_layers)])
        self.dec_norm = nn.LayerNorm(d_model)
        self.drop = nn.Dropout(dropout)
        self.mdn = MDNHead(d_model, n_mix)

    # 2-D stroke positional encoding: temporal index + absolute pen position
    def _embed_strokes(self, x_in, proj):
        T = x_in.size(1)
        xy = torch.cumsum(x_in[..., :2] * self.sd + self.mu, 1) * self.pos_scale
        return self.drop(proj(x_in) + self.pe[:T] + abs_pos_encoding(xy, self.d))

    def encode(self, text, text_mask, ref, ref_mask):
        t = self.drop(self.char_emb(text) * math.sqrt(self.d) + self.pe[: text.size(1)])
        t = self.text_enc(t, src_key_padding_mask=~text_mask)
        s = self.style_enc(self._embed_strokes(ref, self.style_in), src_key_padding_mask=~ref_mask)
        m = ref_mask.unsqueeze(-1).float()
        style_vec = (s * m).sum(1) / m.sum(1).clamp(min=1)
        mem = torch.cat([s, t], 1)
        kpm = torch.cat([~ref_mask, ~text_mask], 1)
        return mem, kpm, self.style_cls(style_vec)

    def decode(self, x_in, mem, kpm):
        T = x_in.size(1)
        causal = torch.triu(torch.ones(T, T, dtype=torch.bool, device=x_in.device), 1)
        h = self._embed_strokes(x_in, self.in_proj)
        for layer in self.dec:
            h = layer(h, mem, causal, kpm)
        return self.dec_norm(h)

    def forward(self, x, text, text_mask, ref, ref_mask):
        B = x.size(0)
        x_in = torch.cat([x.new_zeros(B, 1, 3), x[:, :-1]], 1)
        mem, kpm, style_logits = self.encode(text, text_mask, ref, ref_mask)
        return self.mdn(self.decode(x_in, mem, kpm)), style_logits

    @torch.no_grad()
    def generate(self, text, ref, length, bias=0.5, generator=None):
        text_mask = text > 0
        ref_mask = torch.ones(ref.shape[:2], dtype=torch.bool, device=ref.device)
        mem, kpm, _ = self.encode(text, text_mask, ref, ref_mask)
        seq = torch.zeros(1, 1, 3, device=text.device)
        outs = []
        for _ in range(length):
            out = self.mdn(self.decode(seq, mem, kpm)[:, -1])
            s = sample_mdn(out, self.M, bias, generator)
            outs.append(s)
            seq = torch.cat([seq, s.unsqueeze(1)], 1)
        return torch.stack(outs, 1)
