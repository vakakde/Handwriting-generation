"""Values REPORTED in the manuscript (Tables 3, 4, 5).  Used only as a reference overlay in the comparison figures/tables."""
PAPER_T3 = {   # model: FID, SSIM, OCR acc (%), train time (h), inference (s)
    "lstm":        dict(fid=18.7, ssim=0.73, ocr_acc=0.783, train_time_h=12.3, inference_time_s=0.045),
    "gan":         dict(fid=15.2, ssim=0.81, ocr_acc=0.847, train_time_h=28.7, inference_time_s=0.023),
    "transformer": dict(fid=12.3, ssim=0.87, ocr_acc=0.912, train_time_h=15.8, inference_time_s=0.031),
}
PAPER_T3_SD = {"lstm": (2.1, 0.08, 0.032), "gan": (1.8, 0.06, 0.028), "transformer": (1.5, 0.04, 0.021)}   # FID, SSIM, OCR SDs
PAPER_T4 = {   # legibility, naturalness, style consistency (mean, sd)
    "lstm": ((6.8, 1.2), (6.3, 1.4), (7.1, 1.1)),
    "gan": ((7.9, 1.0), (7.8, 1.2), (7.3, 1.3)),
    "transformer": ((8.7, 0.9), (8.5, 1.0), (8.2, 1.1)),
}
PAPER_T5 = {   # visual quality, temporal consistency, style control, training stability, computational efficiency, overall
    "lstm": (6.8, 9.4, 7.2, 9.1, 6.5, 7.8),
    "gan": (9.6, 5.8, 7.8, 5.2, 8.9, 7.5),
    "transformer": (7.8, 7.8, 7.4, 8.2, 7.1, 7.7),
}
PAPER_ABLATION = {"with_attention": dict(fid=12.3, ssim=0.87, ocr_acc=0.912), "without_attention": dict(fid=16.8, ssim=0.79, ocr_acc=0.854)}
