"""
Common rendering + canonicalisation module (manuscript Sec. 4.4 (iv)).

The SAME functions are applied to real strokes and to every model output so
that FID, SSIM, OCR and the human evaluation all see identical image formats.

Conventions
-----------
* online strokes: array (T, 3) = (dx, dy, p); p = 1 marks the last point of a stroke (pen lift).
* images: float32 in [0, 1], white background = 1, ink = dark (0).
"""
from __future__ import annotations
import numpy as np
import cv2


def strokes_to_abs(offsets: np.ndarray, mean: np.ndarray, std: np.ndarray):
    """(a) de-standardise with TRAIN statistics and accumulate -> absolute pen coordinates."""
    o = np.nan_to_num(np.asarray(offsets, dtype=np.float64))
    xy = np.cumsum(o[:, :2] * std + mean, axis=0)
    pen = o[:, 2] > 0.5
    return xy, pen


def split_strokes(xy: np.ndarray, pen: np.ndarray):
    """(b) split the point sequence into strokes at p_t = 1."""
    strokes, start = [], 0
    for i in range(len(xy)):
        if pen[i] or i == len(xy) - 1:
            strokes.append(xy[start:i + 1])
            start = i + 1
    return strokes


def render_polylines(xy: np.ndarray, pen: np.ndarray, pen_width: int = 3, ssaa: int = 4,
                     pad: int = 10, max_side: int = 3000) -> np.ndarray:
    """(c) anti-aliased polylines, fixed pen width, black ink on white, rendered at ssaa x and area-downsampled."""
    if len(xy) == 0:
        return np.ones((64, 64), np.float32)
    mn, mx = xy.min(0), xy.max(0)
    extent = float(max(mx[0] - mn[0], mx[1] - mn[1], 1.0))
    if extent > max_side:                       # guard against diverging (untrained) generators
        xy = (xy - mn) * (max_side / extent) + mn
        mn, mx = xy.min(0), xy.max(0)
    w = int(np.ceil(mx[0] - mn[0])) + 2 * pad + 1
    h = int(np.ceil(mx[1] - mn[1])) + 2 * pad + 1
    big = np.full((h * ssaa, w * ssaa), 255, np.uint8)
    for s in split_strokes(xy, pen):
        pts = np.round((s - mn + pad) * ssaa).astype(np.int32)
        if len(pts) == 1:
            cv2.circle(big, tuple(int(v) for v in pts[0]), max(1, pen_width * ssaa // 2), 0, -1, cv2.LINE_AA)
        else:
            cv2.polylines(big, [pts.reshape(-1, 1, 2)], False, 0, pen_width * ssaa, cv2.LINE_AA)
    small = cv2.resize(big, (w, h), interpolation=cv2.INTER_AREA)
    return small.astype(np.float32) / 255.0


def canonicalise(img: np.ndarray, size: int = 512, margin: int = 24, thr: float = 0.5) -> np.ndarray:
    """Crop to the ink bounding box (threshold 0.5), fit into size x size with `margin`
    preserving the aspect ratio (area interpolation), centre on white.  No slant/baseline correction."""
    img = np.clip(np.nan_to_num(img.astype(np.float32), nan=1.0), 0.0, 1.0)
    canvas = np.ones((size, size), np.float32)
    ys, xs = np.where(img < thr)
    if len(ys) == 0:
        return canvas
    crop = img[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    h, w = crop.shape
    s = min((size - 2 * margin) / w, (size - 2 * margin) / h)
    nw, nh = max(1, int(round(w * s))), max(1, int(round(h * s)))
    interp = cv2.INTER_AREA if s < 1.0 else cv2.INTER_LINEAR   # INTER_AREA degenerates to nearest when enlarging
    crop = cv2.resize(crop, (nw, nh), interpolation=interp)
    y0, x0 = (size - nh) // 2, (size - nw) // 2
    canvas[y0:y0 + nh, x0:x0 + nw] = crop
    return canvas


def strokes_to_canonical(offsets, mean, std, size=512, margin=24, pen_width=3, ssaa=4, thr=0.5):
    xy, pen = strokes_to_abs(offsets, mean, std)
    return canonicalise(render_polylines(xy, pen, pen_width, ssaa), size, margin, thr)


def raster_to_canonical(img01: np.ndarray, size=512, margin=24, thr=0.5):
    """GAN output: single-channel grayscale in [0,1] with ink-dark polarity -> canonical image."""
    return canonicalise(img01, size, margin, thr)
