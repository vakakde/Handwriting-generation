"""
One command for everything:  train -> evaluate -> human-study statistics -> comparison analysis.

  python run_all.py --smoke                         # CPU, synthetic data, a few minutes (pipeline test)
  python run_all.py --data_root /data/IAM-OnDB --ablation --n_eval 200
  python run_all.py --data_root ... --human_ratings ratings.csv --human_prefs preferences.csv   # real rater data

Without --human_ratings the human-evaluation step uses SIMULATED ratings (clearly labelled) so the analysis code is exercised.
"""
import argparse, os, subprocess, sys

here = os.path.dirname(os.path.abspath(__file__))
ap = argparse.ArgumentParser(add_help=False)
ap.add_argument("--smoke", action="store_true")
ap.add_argument("--out_dir", default=None)
ap.add_argument("--human_ratings"); ap.add_argument("--human_prefs")
a, rest = ap.parse_known_args()
out = a.out_dir or ("runs/smoke" if a.smoke else "runs/main")
py = sys.executable
run = lambda *c: subprocess.run([py, *c], cwd=here, check=True)

run("run_experiment.py", *(["--smoke"] if a.smoke else []), "--out_dir", out, *rest)
hd = os.path.join(out, "human")
if a.human_ratings and a.human_prefs:
    run("human_eval.py", "analyse", "--ratings", a.human_ratings, "--prefs", a.human_prefs, "--out_dir", hd)
else:
    run("human_eval.py", "simulate", "--out_dir", hd)
run("analysis.py", "--run_dir", out, "--human_dir", hd)
print(f"\nAll outputs in {os.path.join(here, out)}  (tables + figures in {out}/analysis/)")
