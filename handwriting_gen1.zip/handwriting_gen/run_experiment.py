"""
End-to-end experiment: data -> train (3 architectures x seeds) -> unified evaluation -> metrics.csv / histories.
Usage:
    python run_experiment.py --smoke                      # CPU pipeline test on synthetic data
    python run_experiment.py --data_root /path/IAM-OnDB   # full run with the manuscript's settings
"""
from __future__ import annotations
import argparse, json, os, sys, time
import numpy as np
import pandas as pd
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import Config
from data import (Vocab, load_samples, writer_level_split, train_stats, StrokeDataset, build_image_cache)
from train import train_model, get_device, set_seed
from evaluate import EvalContext, evaluate_model, save_real_samples, load_trained


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--data_root", default=None)
    ap.add_argument("--out_dir", default=None)
    ap.add_argument("--models", nargs="+", default=["lstm", "gan", "transformer"])
    ap.add_argument("--ablation", action="store_true", help="also train/evaluate the Transformer without self-attention")
    ap.add_argument("--seeds", nargs="+", type=int, default=None)
    ap.add_argument("--epochs", type=int, default=None)
    ap.add_argument("--n_eval", type=int, default=None)
    ap.add_argument("--device", default=None)
    ap.add_argument("--skip_train", action="store_true", help="re-use existing checkpoints")
    a = ap.parse_args()

    cfg = Config.smoke() if a.smoke else Config()
    for k in ("data_root", "out_dir", "seeds", "epochs", "n_eval", "device"):
        if getattr(a, k) is not None:
            setattr(cfg, k, getattr(a, k))
    os.makedirs(cfg.out_dir, exist_ok=True)
    cfg.save(os.path.join(cfg.out_dir, "config.json"))
    dev = get_device(cfg)
    print(f"[run] device={dev} out={cfg.out_dir}")

    # ------------------------------------------------------------------ data
    samples, synthetic = load_samples(cfg)
    idx, parts = writer_level_split(samples, cfg)
    stats = train_stats(samples, idx["train"])
    vocab = Vocab()
    writer_map = {w: i for i, w in enumerate(sorted(parts["train"]))}          # labels exist for TRAIN writers only
    json.dump(dict(parts=parts, synthetic=synthetic, steps_per_char=stats["steps_per_char"]),
              open(os.path.join(cfg.out_dir, "split.json"), "w"), indent=1)
    ds_tr = StrokeDataset(samples, idx["train"], vocab, stats, writer_map, train=True, seed=cfg.split_seed)
    ds_va = StrokeDataset(samples, idx["val"], vocab, stats, writer_map, train=False)
    ds_te = StrokeDataset(samples, idx["test"], vocab, stats, writer_map, train=False)
    need_gan = "gan" in a.models
    img_cache = build_image_cache(samples, stats, cfg, os.path.join(cfg.out_dir, "cache", "images.npz")) if need_gan else None

    ctx = EvalContext(cfg, samples, ds_te, vocab, stats, dev)
    save_real_samples(ctx, os.path.join(cfg.out_dir, "samples"))

    import platform, importlib
    def _ver(m):
        try:
            return importlib.import_module(m).__version__
        except Exception:
            return "not installed"
    json.dump(dict(n_test=len(ctx.items), n_test_pool=len(ds_te), synthetic=synthetic,
                   stroke_mean=stats["mean"].tolist(), stroke_std=stats["std"].tolist(), steps_per_char=stats["steps_per_char"],
                   python=platform.python_version(), torch=_ver("torch"), torchvision=_ver("torchvision"), scipy=_ver("scipy"),
                   scikit_image=_ver("skimage"), opencv=_ver("cv2"), pytorch_fid=_ver("pytorch_fid"),
                   fid_extractor=("torchvision Inception-v3 (IMAGENET1K_V1)" if ctx.feat.pretrained else "RANDOM weights (pseudo-FID)"),
                   ocr_engine=ctx.ocr.name), open(os.path.join(cfg.out_dir, "eval_params.json"), "w"), indent=1)

    names = list(a.models) + (["transformer_noattn"] if a.ablation else [])
    rows = []
    for seed in cfg.seeds:
        for name in names:
            ck = os.path.join(cfg.out_dir, "ckpt", f"{name}_seed{seed}.pt")
            hp = os.path.join(cfg.out_dir, "ckpt", f"{name}_seed{seed}_history.json")
            if a.skip_train and os.path.exists(ck):
                model, hist = load_trained(name, cfg, vocab, stats, ck, dev), json.load(open(hp))
            else:
                model, hist = train_model(name, cfg, seed, ds_tr, ds_va, vocab, stats, len(writer_map), img_cache, dev, cfg.out_dir)
            m = evaluate_model(name, model, ctx, seed, img_cache, os.path.join(cfg.out_dir, "samples"))
            m.update(train_time_h=hist["train_time_s"] / 3600.0, n_params=hist["n_params"],
                     final_train_loss=hist["train_loss"][-1], final_val_loss=hist["val_loss"][-1],
                     val_volatility=float(np.mean(np.abs(np.diff(hist["val_loss"])) / (np.abs(hist["val_loss"][1:]) + 1e-9))) if len(hist["val_loss"]) > 1 else 0.0,
                     synthetic_data=synthetic)
            rows.append(m)
            print("[result]", {k: (round(v, 4) if isinstance(v, float) else v) for k, v in m.items()})
            pd.DataFrame(rows).to_csv(os.path.join(cfg.out_dir, "metrics.csv"), index=False)
            del model
    pd.DataFrame(rows).to_csv(os.path.join(cfg.out_dir, "metrics.csv"), index=False)
    pd.DataFrame([dict(model="real", ocr_acc=ctx.ocr_real, ocr_engine=ctx.ocr.name)]).to_csv(
        os.path.join(cfg.out_dir, "real_reference.csv"), index=False)
    print(f"[run] done -> {cfg.out_dir}/metrics.csv")


if __name__ == "__main__":
    main()
