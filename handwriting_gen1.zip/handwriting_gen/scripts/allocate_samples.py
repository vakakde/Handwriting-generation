import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.argv.insert(1, "allocate")
import human_eval; human_eval.main()
