import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
sys.argv.insert(1, "analyse")      # --ratings ratings.csv --prefs prefs.csv --out_dir ...
import human_eval; human_eval.main()
