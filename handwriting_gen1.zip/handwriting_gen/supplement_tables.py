"""
Builds the data for every table of the Supplementary Materials from the data files:

  S3-1  design (counts VERIFIED from allocation/ratings)       S3-2  test results (Friedman, Wilcoxon+Holm, alpha)
  S3-3  participant + preference counts                         S4-1  rendering / metric / training parameters
  S5-1  repository contents and status                          + configs/eval.yaml

    python supplement_tables.py --ratings ratings.csv --prefs prefs.csv --allocation allocation.csv --run_dir runs/main --out_dir supp
    python supplement_tables.py --simulate --run_dir runs/smoke --out_dir supp_simulated      # TEST DATA ONLY
"""
from __future__ import annotations
import argparse, json, os, platform
import numpy as np
import pandas as pd

import human_eval as H
from analysis import to_md
from config import Config

CRIT_LABEL = {"legibility": "Legibility", "naturalness": "Naturalness", "style_consistency": "Style consistency", "overall_quality": "Overall quality"}


def fp(p):
    return "<0.001" if p < 0.001 else f"{p:.3f}"


def table_s3_1(alloc, ratings, cfg):
    n = alloc.participant_id.nunique(); K = alloc.trial.nunique()
    cat = alloc.drop_duplicates("participant_id").category.value_counts().reindex(H.CATEGORIES)
    n_samples = ratings.groupby(["participant_id", "trial", "model"]).ngroups
    per_model = ratings.groupby("model").apply(lambda d: d.groupby(["participant_id", "trial"]).ngroups)
    perm_cnt = alloc.groupby(["participant_id"]).apply(lambda d: d[["label_A", "label_B", "label_C"]].astype(str).agg("-".join, axis=1).value_counts())
    balanced = bool((perm_cnt == K // 6).all() and perm_cnt.groupby(level=0).size().eq(6).all())
    use = alloc.prompt_idx.value_counts()
    items = ratings.groupby("item").size()
    rows = [
        ("Participants", f"{n} ({cat.iloc[0]} faculty + {cat.iloc[1]} PhD scholars + {cat.iloc[2]} postgraduate students = {cat.sum()})"),
        ("Participant codes", f"{alloc.participant_id.min()}–{alloc.participant_id.max()}"),
        ("Trials per participant", f"K = {K}"),
        ("Number of ratings (samples)", f"{n} × {K} × 3 = {n * K * 3}; found in ratings file: {n_samples} samples ({', '.join(f'{m}: {per_model[m]}' for m in H.MODELS)})"),
        ("Items", f"{items.size} items (" + ", ".join(f"{k}:{len(v)}" for k, v in H.ITEMS.items()) + f"); {len(ratings)} item scores in total"),
        ("Counterbalancing", f"each of the 6 permutations appears K/6 = {K // 6}× per participant: {'VERIFIED' if balanced else 'NOT balanced'} (seed {cfg.human_seed})"),
        ("Prompt selection", f"{alloc.prompt_idx.nunique()} distinct prompts; used {use.min()}–{use.max()}× each; no repeats within a participant: "
                             f"{'VERIFIED' if alloc.groupby('participant_id').prompt_idx.nunique().eq(K).all() else 'VIOLATED'}"),
        ("Score range", f"{ratings.score.min()}–{ratings.score.max()} (scale 1–10)"),
    ]
    return pd.DataFrame(rows, columns=["Aspect", "Verified specification"])


def table_s3_2(res):
    fr, pw, ca = res["friedman"].set_index("criterion"), res["pairwise"], res["cronbach"].set_index("criterion")
    rows = []
    for c in H.CRITERIA:
        row = {"Criterion": CRIT_LABEL[c], "Friedman χ²(2)": f"{fr.loc[c, 'chi2']:.2f}", "p": fp(fr.loc[c, "p"]),
               "Kendall's W": f"{fr.loc[c, 'kendall_W']:.3f}"}
        for a, b, name in [("lstm", "gan", "LSTM vs GAN (Holm p, r)"), ("lstm", "transformer", "LSTM vs Transformer (Holm p, r)"),
                           ("gan", "transformer", "GAN vs Transformer (Holm p, r)")]:
            r = pw[(pw.criterion == c) & (pw.pair == f"{a} vs {b}")].iloc[0]
            row[name] = f"{fp(r.p_holm)}, {r.r_rb:+.2f}"
        row["Cronbach's α"] = f"{ca.loc[c, 'alpha']:.2f}"
        rows.append(row)
    return pd.DataFrame(rows)


def table_s3_3(ratings, prefs):
    cat = ratings.drop_duplicates("participant_id").set_index("participant_id").category
    p = prefs.copy(); p["category"] = p.participant_id.map(cat)
    cell = lambda d: " / ".join(str(int((d == m).sum())) for m in H.MODELS)
    rows = []
    for c in H.CATEGORIES + ["Total"]:
        d = p if c == "Total" else p[p.category == c]
        row = {"Category": c, "n": d.participant_id.nunique()}
        for q, nm in zip(H.Q_IDS, ["Q1 (readability)", "Q2 (naturalness)", "Q3 (style consistency)", "Q4 (document suitability)"]):
            row[nm + " LSTM / GAN / Transformer"] = cell(d[d.question == q].chosen_model)
        rows.append(row)
    return pd.DataFrame(rows)


def table_s4_1(cfg, ep):
    g = lambda k, d="[fill in]": ep.get(k, d)
    st = f"mean = {np.round(ep['stroke_mean'], 4).tolist()}, SD = {np.round(ep['stroke_std'], 4).tolist()}" if "stroke_mean" in ep else "[from training split]"
    rows = [
        ("Test content", f"Same N = {g('n_test')} writer-disjoint test samples for every model (test pool: {g('n_test_pool')}); same text c and same writer-style reference; one output per model per seed."),
        ("Stroke representation", f"(Δx_t, Δy_t, p_t), p_t = 1 at the last point of a stroke; offsets standardised with training-set {st}; steps/char = {g('steps_per_char', '?') if not isinstance(g('steps_per_char'), float) else round(g('steps_per_char'), 2)}."),
        ("Stroke → image", f"De-standardise → cumsum → split at p_t = 1 → polylines; pen width {cfg.pen_width} px; {cfg.ssaa}× supersampling, area down-sampling; black ink (0) on white (1)."),
        ("GAN output → image", "Grayscale in [0,1]; ink-dark polarity (generator trained with ink = −1); invert if white-on-black."),
        ("Canonicalisation", f"Ink bounding box (pixel < {cfg.ink_threshold}) → crop → area-interpolation fit to {cfg.canvas}×{cfg.canvas} with {cfg.margin} px margin, aspect preserved → centre on white. No slant/baseline correction."),
        ("Real reference", "Ground-truth strokes of the same N test samples, rendered with the same function (not the original scans)."),
        ("FID", f"Inception-v3 pool3 2048-d; grayscale ×3 channels; 299×299 bilinear; real vs generated sets of equal size N. Extractor used: {g('fid_extractor')}. "
                f"Implementation: this package's frechet_distance (exact for small N); the pytorch-fid package was not used (its TF-ported Inception weights give slightly different FID values)."),
        ("SSIM", f"Paired generated vs ground truth; Gaussian window 11×11, σ = 1.5, K1 = 0.01, K2 = 0.03, data range 1.0; scikit-image {g('scikit_image')}."),
        ("OCR accuracy", f"Single pre-trained recogniser: {g('ocr_engine')}; no fine-tuning; identical decoding (greedy) for all models; accuracy = 1 − CER (clipped at 0); case-sensitive."),
        ("Repeats", f"Seeds {cfg.seeds[0]}–{cfg.seeds[-1]} per model; mean ± SD over seeds; writer-level split {int(cfg.split[0]*100)}/{int(cfg.split[1]*100)}/{int(cfg.split[2]*100)} % (seed {cfg.split_seed})."),
        ("Training", f"Adam (β1 = {cfg.betas[0]}, β2 = {cfg.betas[1]}), lr {cfg.lr}, cosine annealing, {cfg.epochs} epochs, weight decay {cfg.weight_decay}; batch size {cfg.batch_size} (LSTM, Transformer) and {cfg.gan_batch_size} (GAN); "
                     f"hardware: [authors: NVIDIA V100]; Python {g('python')}, PyTorch {g('torch')}, torchvision {g('torchvision')}, SciPy {g('scipy')}."),
    ]
    return pd.DataFrame(rows, columns=["Step", "Parameter / value"])


def table_s5_1():
    P = "Provided in this package"
    rows = [
        ("Pre-processing, writer-level split lists (train/val/test)", "data.py; runs/<run>/split.json (written by run_experiment.py)", P + " (split lists are generated from IAM-OnDB by the authors' run)"),
        ("LSTM, GAN, Transformer implementations and training configs", "models/lstm.py, models/gan.py, models/transformer.py, train.py, config.py", P),
        ("Common rendering and canonicalisation module", "render.py", P),
        ("FID, SSIM and OCR evaluation", "metrics.py, evaluate.py, configs/eval.yaml", P + " (OCR engine + stroke statistics are filled from the run: runs/<run>/eval_params.json)"),
        ("Human-evaluation allocation and statistics", "scripts/allocate_samples.py, scripts/stats_human_eval.py, human_eval.py", P + " (tested on SIMULATED data only)"),
        ("Supplement table builder", "supplement_tables.py (scripts/make_supplement_tables.py)", P),
        ("Anonymised raw ratings (ratings.csv, prefs.csv) and allocation.csv", "data/human_eval/", "[authors: add REAL ratings/prefs; allocation.csv is reproducible with seed 2026]"),
        ("Trained checkpoints", "releases/", "[authors: optional, licence permitting]"),
        ("Persistent archive", "Zenodo DOI", "[authors: create release v1.0]"),
        ("Public URL", "GitHub / institutional repository", "[authors: insert]"),
    ]
    return pd.DataFrame(rows, columns=["Component", "Location", "Status"])


def write_eval_yaml(cfg, ep, path):
    y = [f"# configs/eval.yaml - shared by LSTM, GAN, Transformer and real reference",
         f"canvas: {cfg.canvas}", f"margin: {cfg.margin}", f"pen_width: {cfg.pen_width}", f"ssaa: {cfg.ssaa}", f"ink_threshold: {cfg.ink_threshold}",
         f"n_eval: {ep.get('n_test', cfg.n_eval)}", f"eval_seed: {cfg.eval_seed}", f"seeds: {cfg.seeds}", f"split: {list(cfg.split)}", f"split_seed: {cfg.split_seed}",
         f"sample_bias: {cfg.sample_bias}", f"length_mode: {cfg.length_mode}", f"steps_per_char: {ep.get('steps_per_char', 'from training split')}",
         f"stroke_mean: {ep.get('stroke_mean', 'from training split')}", f"stroke_std: {ep.get('stroke_std', 'from training split')}",
         "ssim: {win_size: 11, sigma: 1.5, k1: 0.01, k2: 0.03, data_range: 1.0, gaussian_weights: true}",
         f"fid: {{feature: pool3-2048, input_size: 299, extractor: \"{ep.get('fid_extractor', '?')}\"}}",
         f"ocr: {{engine: \"{ep.get('ocr_engine', '?')}\", metric: 1-CER, case_sensitive: true}}",
         f"train: {{optimizer: Adam, betas: {list(cfg.betas)}, lr: {cfg.lr}, weight_decay: {cfg.weight_decay}, epochs: {cfg.epochs}, batch_lstm_transformer: {cfg.batch_size}, batch_gan: {cfg.gan_batch_size}}}"]
    open(path, "w").write("\n".join(y) + "\n")


def save(df, out, name, banner=""):
    df.to_csv(os.path.join(out, name + ".csv"), index=False)
    open(os.path.join(out, name + ".md"), "w").write((banner + "\n\n" if banner else "") + to_md(df, "{:.3f}") + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ratings"); ap.add_argument("--prefs"); ap.add_argument("--allocation")
    ap.add_argument("--simulate", action="store_true"); ap.add_argument("--run_dir", default=None)
    ap.add_argument("--out_dir", default="supplement_tables")
    a = ap.parse_args()
    cfg = Config(); os.makedirs(a.out_dir, exist_ok=True)
    ep = json.load(open(os.path.join(a.run_dir, "eval_params.json"))) if a.run_dir and os.path.exists(os.path.join(a.run_dir, "eval_params.json")) else {}
    if a.simulate:
        alloc = H.make_allocation(cfg.n_participants, cfg.n_trials, max(ep.get("n_test_pool", 100), 6) if False else 100, cfg.human_seed, cfg.category_counts)
        ratings, prefs = H.simulate_ratings(alloc, cfg.human_seed)
        tag, banner = "SIMULATED_", "**SIMULATED DATA - generated by human_eval.simulate_ratings() to test the pipeline. NOT participant data; do not report.**"
        ratings.to_csv(os.path.join(a.out_dir, "SIMULATED_ratings.csv"), index=False); prefs.to_csv(os.path.join(a.out_dir, "SIMULATED_prefs.csv"), index=False)
    else:
        ratings, prefs, alloc = pd.read_csv(a.ratings), pd.read_csv(a.prefs), pd.read_csv(a.allocation)
        tag, banner = "", ""
    alloc.to_csv(os.path.join(a.out_dir, "allocation.csv"), index=False)
    res = H.analyse(ratings, prefs)
    H.write_report(res, os.path.join(a.out_dir, "full_stats"), simulated=a.simulate)
    save(table_s3_1(alloc, ratings, cfg), a.out_dir, "Table_S3-1_design_verified")
    save(table_s3_2(res), a.out_dir, tag + "Table_S3-2_test_results", banner)
    save(table_s3_3(ratings, prefs), a.out_dir, tag + "Table_S3-3_participants_preferences", banner)
    save(table_s4_1(cfg, ep), a.out_dir, "Table_S4-1_parameters")
    save(table_s5_1(), a.out_dir, "Table_S5-1_repository_status")
    os.makedirs(os.path.join(a.out_dir, "configs"), exist_ok=True)
    write_eval_yaml(cfg, ep, os.path.join(a.out_dir, "configs", "eval.yaml"))
    print("written to", a.out_dir)


if __name__ == "__main__":
    main()
