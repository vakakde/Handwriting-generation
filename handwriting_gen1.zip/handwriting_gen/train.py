"""
Training for all three architectures under one protocol (Adam, lr 1e-3, cosine annealing, weight decay 1e-4,
100 epochs, validation on the held-out writer-level validation split, best-validation checkpoint).
"""
from __future__ import annotations
import math, os, random, time, json
import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from config import Config
from data import StrokeDataset, collate, to_device
from models import build_model, count_params
from models.common import mdn_nll


def set_seed(s: int):
    random.seed(s); np.random.seed(s); torch.manual_seed(s); torch.cuda.manual_seed_all(s)


def get_device(cfg: Config):
    if cfg.device == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(cfg.device)


def _sync(dev):
    if dev.type == "cuda":
        torch.cuda.synchronize()


# ============================================================ LSTM / Transformer
def seq_forward(model, name, b, cfg):
    """returns (nll, aux) ; aux = writer-ID cross-entropy of the style encoder (Transformer only)."""
    if name == "lstm":
        out = model(b["strokes"], b["text"], b["text_mask"])
        return mdn_nll(out, b["strokes"], b["stroke_mask"], cfg.n_mix), None
    out, sl = model(b["strokes"], b["text"], b["text_mask"], b["ref_strokes"], b["ref_mask"])
    nll = mdn_nll(out, b["strokes"], b["stroke_mask"], cfg.n_mix)
    w = b["writer"]
    ce = F.cross_entropy(sl[w >= 0], w[w >= 0]) if (w >= 0).any() else None
    return nll, ce


def train_seq(name, cfg, seed, ds_tr, ds_va, vocab, stats, n_writers, dev, log=print):
    set_seed(seed)
    model = build_model(name, cfg, vocab.size, stats, n_writers).to(dev)
    clip = cfg.grad_clip_lstm if name == "lstm" else cfg.grad_clip_transformer
    ce_w = cfg.tf_style_ce_weight
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr, betas=cfg.betas, weight_decay=cfg.weight_decay)
    tl = DataLoader(ds_tr, cfg.batch_size, shuffle=True, collate_fn=collate, drop_last=len(ds_tr) >= cfg.batch_size,
                    num_workers=cfg.num_workers)
    vl = DataLoader(ds_va, cfg.batch_size, shuffle=False, collate_fn=collate)
    total = max(1, cfg.epochs * len(tl))
    sched = torch.optim.lr_scheduler.LambdaLR(
        opt, lambda s: min(1.0, (s + 1) / max(1, cfg.warmup_steps)) * 0.5 * (1 + math.cos(math.pi * min(s, total) / total)))
    hist = dict(train_loss=[], val_loss=[], lr=[], epoch_time=[])
    best, best_state = float("inf"), None
    for ep in range(cfg.epochs):
        t0 = time.time(); model.train(); run, n = 0.0, 0
        for b in tl:
            b = to_device(b, dev)
            nll, ce = seq_forward(model, name, b, cfg)
            loss = nll + (ce_w * ce if ce is not None else 0.0)
            opt.zero_grad(set_to_none=True); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), clip)
            opt.step(); sched.step()
            run += nll.item(); n += 1
        model.eval(); vs, vn = 0.0, 0
        with torch.no_grad():
            for b in vl:
                nll, _ = seq_forward(model, name, to_device(b, dev), cfg)
                vs += nll.item(); vn += 1
        _sync(dev)
        hist["train_loss"].append(run / max(n, 1)); hist["val_loss"].append(vs / max(vn, 1))
        hist["lr"].append(opt.param_groups[0]["lr"]); hist["epoch_time"].append(time.time() - t0)
        if hist["val_loss"][-1] < best:
            best = hist["val_loss"][-1]
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        log(f"[{name} s{seed}] ep {ep + 1}/{cfg.epochs} train NLL {hist['train_loss'][-1]:.3f} val NLL {hist['val_loss'][-1]:.3f} ({hist['epoch_time'][-1]:.1f}s)")
    model.load_state_dict(best_state)
    return model, hist


# ======================================================================== GAN
def _imgs(cache, idx, res, dev):
    x = cache[idx.cpu()].to(dev).float().div(127.5).sub(1.0).unsqueeze(1)          # white=+1, ink=-1
    return x if x.size(-1) == res else F.interpolate(x, size=(res, res), mode="area")


def train_gan(cfg, seed, ds_tr, ds_va, img_cache, vocab, stats, n_writers, dev, log=print):
    set_seed(seed)
    cache = torch.from_numpy(img_cache)
    bundle = build_model("gan", cfg, vocab.size, stats, n_writers).to(dev)
    R, style_res = max(cfg.gan_res_schedule), bundle.style_enc.res
    pG = list(bundle.G.parameters()) + list(bundle.text_enc.parameters()) + list(bundle.style_enc.parameters())
    lr = cfg.gan_lr if cfg.gan_lr > 0 else cfg.lr
    oG = torch.optim.Adam(pG, lr=lr, betas=cfg.betas, weight_decay=cfg.weight_decay)
    oD = torch.optim.Adam(bundle.D.parameters(), lr=lr, betas=cfg.betas, weight_decay=cfg.weight_decay)
    sG = torch.optim.lr_scheduler.CosineAnnealingLR(oG, cfg.epochs)
    sD = torch.optim.lr_scheduler.CosineAnnealingLR(oD, cfg.epochs)
    tl = DataLoader(ds_tr, cfg.gan_batch_size, shuffle=True, collate_fn=collate, drop_last=len(ds_tr) >= cfg.gan_batch_size)
    vl = DataLoader(ds_va, cfg.gan_batch_size, shuffle=False, collate_fn=collate)
    n_st, per = len(cfg.gan_res_schedule), cfg.epochs / len(cfg.gan_res_schedule)
    hist = dict(train_loss=[], d_loss=[], val_loss=[], res=[], epoch_time=[])
    best, best_state, step = float("inf"), None, 0
    for ep in range(cfg.epochs):
        t0 = time.time(); bundle.train()
        stage = min(n_st - 1, int(ep / per)); res = cfg.gan_res_schedule[stage]
        gl, dl, n = 0.0, 0.0, 0
        for it, b in enumerate(tl):
            frac = (ep - stage * per + it / len(tl)) / per
            alpha = 1.0 if stage == 0 else min(1.0, frac / 0.5)                    # first half of each stage = fade-in
            b = to_device(b, dev)
            real, ref = _imgs(cache, b["idx"], res, dev), _imgs(cache, b["ref_idx"], style_res, dev)
            z = torch.randn(real.size(0), cfg.gan_z_dim, device=dev)
            # ---------------- discriminator: L_D = -E[log D(x)] - E[log(1-D(G(z,c)))]  (+ R1 gradient penalty)
            with torch.no_grad():
                cond, _ = bundle.cond(b["text"], b["text_mask"], ref)
                fake = bundle.G(z, cond, res, alpha)
            do_r1 = (step % cfg.gan_r1_interval == 0)
            real_in = real.detach().requires_grad_(do_r1)
            d_real, d_fake = bundle.D(real_in, cond, res, alpha), bundle.D(fake, cond, res, alpha)
            lossD = F.softplus(-d_real).mean() + F.softplus(d_fake).mean()
            if do_r1:
                g, = torch.autograd.grad(d_real.sum(), real_in, create_graph=True)
                lossD = lossD + 0.5 * cfg.gan_r1_gamma * cfg.gan_r1_interval * g.pow(2).flatten(1).sum(1).mean()
            oD.zero_grad(set_to_none=True); lossD.backward(); oD.step()
            # ---------------- generator + encoders: L_G = -E[log D(G(z,c))] + lambda * L_rec (+ writer-ID CE)
            cond, logits = bundle.cond(b["text"], b["text_mask"], ref)
            fake = bundle.G(z, cond, res, alpha)
            lossG = F.softplus(-bundle.D(fake, cond, res, alpha)).mean() + cfg.gan_lambda_rec * F.l1_loss(fake, real)
            w = b["writer"]
            if (w >= 0).any():
                lossG = lossG + cfg.gan_style_ce_weight * F.cross_entropy(logits[w >= 0], w[w >= 0])
            oG.zero_grad(set_to_none=True); lossG.backward(); oG.step()
            gl += lossG.item(); dl += lossD.item(); n += 1; step += 1
        sG.step(); sD.step()
        # validation: L1 reconstruction at the current resolution (no NLL exists for a GAN)
        bundle.eval(); vs, vn = 0.0, 0
        with torch.no_grad():
            for b in vl:
                b = to_device(b, dev)
                real, ref = _imgs(cache, b["idx"], res, dev), _imgs(cache, b["ref_idx"], style_res, dev)
                cond, _ = bundle.cond(b["text"], b["text_mask"], ref)
                fake = bundle.G(torch.randn(real.size(0), cfg.gan_z_dim, device=dev), cond, res, 1.0)
                vs += F.l1_loss(fake, real).item(); vn += 1
        _sync(dev)
        hist["train_loss"].append(gl / max(n, 1)); hist["d_loss"].append(dl / max(n, 1))
        hist["val_loss"].append(vs / max(vn, 1)); hist["res"].append(res); hist["epoch_time"].append(time.time() - t0)
        if stage == n_st - 1 and hist["val_loss"][-1] < best:          # model selection only at full resolution
            best = hist["val_loss"][-1]
            best_state = {k: v.detach().cpu().clone() for k, v in bundle.state_dict().items()}
        log(f"[gan s{seed}] ep {ep + 1}/{cfg.epochs} res {res} G {hist['train_loss'][-1]:.3f} D {hist['d_loss'][-1]:.3f} val L1 {hist['val_loss'][-1]:.3f} ({hist['epoch_time'][-1]:.1f}s)")
    if best_state is not None:
        bundle.load_state_dict(best_state)
    return bundle, hist


# ================================================================ dispatcher
def train_model(name, cfg, seed, ds_tr, ds_va, vocab, stats, n_writers, img_cache, dev, out_dir, log=print):
    t0 = time.time()
    if name == "gan":
        model, hist = train_gan(cfg, seed, ds_tr, ds_va, img_cache, vocab, stats, n_writers, dev, log)
    else:
        model, hist = train_seq(name, cfg, seed, ds_tr, ds_va, vocab, stats, n_writers, dev, log)
    hist["train_time_s"] = float(sum(hist["epoch_time"]))
    hist["wall_s"] = time.time() - t0
    hist["n_params"] = count_params(model)
    os.makedirs(os.path.join(out_dir, "ckpt"), exist_ok=True)
    torch.save({"state": model.state_dict(), "n_writers": n_writers}, os.path.join(out_dir, "ckpt", f"{name}_seed{seed}.pt"))
    with open(os.path.join(out_dir, "ckpt", f"{name}_seed{seed}_history.json"), "w") as f:
        json.dump(hist, f)
    return model, hist
